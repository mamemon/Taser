package Taser;

import java.awt.Color;
import java.rmi.RemoteException;
import java.security.Permission;
import java.security.Permissions;

import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import Taser.Ui.Cui.ConsoleUserInterface;
import Taser.Ui.Gui.GraphicUserInterface;
import Taser.WorkflowSimulator.WorkflowSimulatorController;
import Taser.WorkflowSimulator.WorkflowSimulatorLocalController;


public class Main {

	/**
	 * @param args  args[0] = "console" or ="gui" in order to launch the right ui. By default the gui is launched.  
	 * @throws UnsupportedLookAndFeelException 
	 * @throws IllegalAccessException 
	 * @throws InstantiationException 
	 * @throws ClassNotFoundException 
	 * @throws RemoteException 
	 */
	public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException, RemoteException{
		
		
		
		if(System.getSecurityManager() == null) {
		    System.setSecurityManager(null);
		     Permission perm = new java.security.AllPermission();
		     Permissions perms = new Permissions();
		     perms.add(perm);
		  }
		
		
		
		// Set System L&F
		UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		UIManager.getDefaults().put("Panel.background", new Color(0, 0, 0, 0));
	
		
		
		WorkflowSimulatorController wsc = new WorkflowSimulatorController();
		
		if(args.length == 0){
			GraphicUserInterface gui = new GraphicUserInterface((WorkflowSimulatorLocalController)wsc);
			wsc.add(gui);
		}else{
			if(args[0].equals("console")){
				ConsoleUserInterface cui = new ConsoleUserInterface((WorkflowSimulatorLocalController) wsc);
				wsc.add(cui);
			}else if(args[0].equals("gui")){
				GraphicUserInterface gui = new GraphicUserInterface((WorkflowSimulatorLocalController)wsc);
				wsc.add(gui);
			}else if (args.length==2){
				GraphicUserInterface gui = new GraphicUserInterface((WorkflowSimulatorLocalController)wsc);
				wsc.add(gui);
				wsc.setLogFileName(args[1]);
				wsc.loadActivityFromFile(args[0]);
			}else{
				System.err.println("Error the requested user interface doesn't exists. You cant give \"console\" as parameter in order to launch Taser in console mode, or \"gui\" in order to lauch the graphic user interface");
				GraphicUserInterface gui = new GraphicUserInterface((WorkflowSimulatorLocalController)wsc);
				wsc.add(gui);			
			}
		}
		
		
		
		
		
	}

}
