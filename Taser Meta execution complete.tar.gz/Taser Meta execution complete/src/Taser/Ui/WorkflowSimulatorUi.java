package Taser.Ui;

import Taser.WorkflowSimulator.WorkflowSimulatorLocalController;

/**
 * The user interface
 * @author rquintin
 *
 */
public abstract class WorkflowSimulatorUi{

	
	/** The controller */
	protected WorkflowSimulatorLocalController wslc;
	
	
	public WorkflowSimulatorUi(WorkflowSimulatorLocalController wslc){
		this.wslc = wslc;
	}
	
	/** 
	 * Draw the activity which has just been loaded
	 */
	public abstract void loadActivity();
	
	
	/**
	 * Update his view of the current simulation
	 */
	public abstract void update();
	
	/**
	 * Print a simple message to user
	 * @param message the message to print
	 */
	public abstract void printMessage(String message);
	
	
	/**
	 * Print an error message to the user
	 * @param errorMessage the error message to print
	 */
	public abstract void printErrorMessage(String errorMessage);
	
	
	
	



}
