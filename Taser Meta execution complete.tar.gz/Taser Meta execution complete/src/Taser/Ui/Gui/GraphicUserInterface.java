package Taser.Ui.Gui;

import javax.swing.JOptionPane;

import Taser.Ui.WorkflowSimulatorUi;
import Taser.WorkflowSimulator.WorkflowSimulatorLocalController;

public class GraphicUserInterface extends WorkflowSimulatorUi {

	
	
	
	
	/** Main Frame */
	private MainFrame mainFrame;
	
	
	
	
	public GraphicUserInterface(WorkflowSimulatorLocalController wslc){
		super(wslc);
		mainFrame = new MainFrame(wslc, this);	
	}
	
	
	@Override
	public void printErrorMessage(String errorMessage) {
		JOptionPane.showMessageDialog(null, errorMessage, "Taser Error", JOptionPane.ERROR_MESSAGE);	
	}

	@Override
	public void printMessage(String message) {
		this.mainFrame.printMessage(message);

	}

	

	@Override
	public void update() {
		mainFrame.update();

	}


	@Override
	public void loadActivity() {
		mainFrame.loadActivity();
		
	}




}
