package Taser.Ui.Gui;

import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import Taser.WorkflowSimulator.WorkflowSimulatorLocalController;

public class MainFrameListener implements WindowListener {
	
	/** The controller in order to process quit on it */
	private WorkflowSimulatorLocalController wscl;
	
	/**
	 * Constructor which set the local controller
	 * @param wscl the local controller
	 */
	public MainFrameListener(WorkflowSimulatorLocalController wscl){
		this.wscl = wscl;
	}
	

	@Override
	public void windowActivated(WindowEvent e) {
		//this.wscl.notif();
	}

	@Override
	public void windowClosed(WindowEvent e) {
		wscl.quit();
	}

	@Override
	public void windowClosing(WindowEvent e) {
		wscl.quit();
	}

	@Override
	public void windowDeactivated(WindowEvent e) {
		//this.wscl.notif();
	}

	@Override
	public void windowDeiconified(WindowEvent e) {
		//this.wscl.notif();
	}

	@Override
	public void windowIconified(WindowEvent e) {		
		//this.wscl.notif();
	}

	@Override
	public void windowOpened(WindowEvent e) {
		//this.wscl.notif();
	}

}
