package Taser.Ui.Gui.VariableDisplayer;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JTable;

public class ButtonEditor extends DefaultCellEditor {

	private static final long serialVersionUID = 7368295246972321967L;
	protected JButton button;
	private ButtonListener bListener = new ButtonListener();
	
	public ButtonEditor(JCheckBox checkBox) {

		super(checkBox);
		button = new JButton();
	    button.setOpaque(true);
	    button.addActionListener(bListener);
	}

	public Component getTableCellEditorComponent(JTable table, Object value,  boolean isSelected, int row, int column) { 

		bListener.setRow(row);
		bListener.setColumn(column);
		bListener.setTable(table);		
		button.setText( (value ==null) ? "" : value.toString() );
	    return button;
	}
	


	class ButtonListener implements ActionListener{
		  
		  private int column, row;
		  private JTable table;		  
		  public void setColumn(int col){this.column = col;}
		  public void setRow(int row){this.row = row;}
		  public void setTable(JTable table){this.table = table;}		  
		  public void actionPerformed(ActionEvent event) {
			ChangeVariableStatusButton cvsb =  (ChangeVariableStatusButton) table.getValueAt(row, column);
			ChangeVariableStatusListener cvsl = cvsb.getCvsl();
			cvsl.actionPerformed(event);
		
		  }
	  }

}
