package Taser.Ui.Gui.VariableDisplayer;

import java.awt.event.ActionEvent;

import Taser.Workflow.Variable;
import Taser.WorkflowSimulator.WorkflowSimulatorLocalController;

public class ChangeVariableStatusListener implements java.awt.event.ActionListener {

	
	/** The variable which will change it status */
	private Variable variable;
	
	/** The local controller */
	private WorkflowSimulatorLocalController wslc;

	
	public ChangeVariableStatusListener(Variable variable,	WorkflowSimulatorLocalController wslc) {
		super();
		this.variable = variable;
		this.wslc = wslc;
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		this.variable.setCorrupted(!this.variable.isCorrupted());
		this.wslc.notif();

	}

}
