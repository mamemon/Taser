package Taser.Ui.Gui.VariableDisplayer;

import java.awt.Component;

import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

public class TableComponent extends DefaultTableCellRenderer {

	
	private static final long serialVersionUID = 2595410860253313460L;

	public Component getTableCellRendererComponent(JTable table,
			Object value, boolean isSelected, boolean hasFocus, int row,
			int column) {

		if (value instanceof ChangeVariableStatusButton){
			return (ChangeVariableStatusButton) value;
		}
		else
			return this;
	}
}