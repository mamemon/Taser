package Taser.Ui.Gui;

public class GuiConfigConstants {

	public static final int LINE_HEIGHT = 15;
	public static final int ACTIVITY_DISPLAYER_VERTICAL_SPACE = 75;
	public static final String IMAGE_PATH = "images/";
}
