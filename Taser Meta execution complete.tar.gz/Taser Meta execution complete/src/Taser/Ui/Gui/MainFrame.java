package Taser.Ui.Gui;

import java.awt.BorderLayout;
import java.awt.HeadlessException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

import Taser.Ui.Gui.ActivityDisplayer.ActivityDisplayer;
import Taser.Ui.Gui.MenuBar.MenuBar;
import Taser.Ui.Gui.Toolbar.Toolbar;
import Taser.Ui.Gui.VariableDisplayer.VariableDisplayer;
import Taser.WorkflowSimulator.WorkflowSimulatorLocalController;

public class MainFrame extends JFrame {



	/**
	 * Automatically generated
	 */
	private static final long serialVersionUID = -3665819717092511513L;

	/** Log printer */
	private Log log;
	
	
	/** Toolbar */
	private Toolbar toolbar;

	/** Activity Displayer */
	private ActivityDisplayer activityDisplayer;

	/** The down tabbedPane */
	private JTabbedPane tabbedPane;
	
	
	/** The variable displayer */
	private VariableDisplayer variableDisplayer;
	
	/*
	 * Graphic component
	 */
	

	/**
	 * This constructor give the local controller to all subcomponent as well as the main gui.
	 * @param wslc The controller which is given to all subcomponent
	 * @param gui The Gui which is given to the all subcomponent
	 */
	public MainFrame(WorkflowSimulatorLocalController wslc, GraphicUserInterface gui) throws HeadlessException {
		super("Taser : Workflow simulator");
			
		
		//Menu
		this.setJMenuBar(new MenuBar(wslc));
		
		
		//Panel
		JPanel panel = new JPanel();
		this.add(panel);
		panel.setLayout(new BorderLayout());
	
		//Tabbed pane
		this.tabbedPane = new JTabbedPane();
		panel.add(tabbedPane, BorderLayout.SOUTH);
		
		//Components
		this.log = new Log();
		tabbedPane.add("Log", log);
		
		this.variableDisplayer = new VariableDisplayer(wslc);
		tabbedPane.add("Workflow's variables", this.variableDisplayer);
		
		this.toolbar = new Toolbar(wslc);
		panel.add(this.toolbar, BorderLayout.NORTH);
		
		
		this.activityDisplayer = new ActivityDisplayer(wslc);
		panel.add(this.activityDisplayer, BorderLayout.CENTER);
	
		
		
		this.addWindowListener(new MainFrameListener(wslc));
		this.setSize(640, 480);
		this.setVisible(true);
		
		
	}

	public void printMessage(String message) {
		this.log.printMessage(message);		
	}
	
	
	public void update() {
		this.activityDisplayer.update();
		this.variableDisplayer.update();
		this.toolbar.update();
		
	}

	public void loadActivity() {
		this.activityDisplayer.loadActivity();
		this.variableDisplayer.update();
		this.toolbar.update();
		
	}



	

}
