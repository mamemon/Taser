package Taser.Ui.Gui.ActivityDisplayer;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import Taser.Workflow.SimpleActivity;
import Taser.Workflow.Variable;


/**
 * Labels are used into the displayer in order to print variables' status when activities are executed. 
 */

public class Label {

	
	
	
	
	/** The activity on which this is connected*/
	private SimpleActivity simpleActivity;
	
	/** The x position of this */
	private int x;
	
	/** The  y position of this*/
	private int y;
	
	/** All variables which name and status are displayed*/
	private Collection<Variable> variables;

	
	public Label(){
		this.variables = new ArrayList<Variable>();		
	}

	
	/**
	 * @return The activity on which this is connected
	 */
	public SimpleActivity getSimpleActivity() {
		return simpleActivity;
	}

	/**
	 * @param simpleActivity The activity on which this is connected to set
	 */
	public void setSimpleActivity(SimpleActivity simpleActivity) {
		this.simpleActivity = simpleActivity;
	}

	/**
	 * @return The x position of this
	 */
	public int getX() {
		return x;
	}

	/**
	 * @param x The x position of this to set
	 */
	public void setX(int x) {
		this.x = x;
	}

	/**
	 * @return The  y position of this
	 */
	public int getY() {
		return y;
	}

	/**
	 * @param y The  y position of this to set
	 */
	public void setY(int y) {
		this.y = y;
	}
	
	
	/**
	 * Copy all variables contains in the given iterator and add all these copies to this
	 * @param variables Variables which will be copied and add to this
	 */
	
	public void addAllVariables(Iterator<Variable> variables){
		while(variables.hasNext()){
			this.variables.add((variables.next().clone()));
		}
	}
	
	/**
	 * Return an iterator on all saved variables
	 * @return an iterator on all saved variables
	 */
	public Iterator<Variable> getVariables(){
		return this.variables.iterator();
	}
	
	
	
	
	
}
