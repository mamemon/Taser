package Taser.Ui.Gui.ActivityDisplayer.ActivityButton;

import java.awt.event.ActionEvent;

import Taser.Workflow.SimpleActivity;
import Taser.WorkflowSimulator.WorkflowSimulatorLocalController;

public class ActivityButtonListenerNext extends ActivityButtonListener {

	public ActivityButtonListenerNext(WorkflowSimulatorLocalController wslc, SimpleActivity activity) {
		super(wslc, activity);		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		this.wslc.next(activity);
	}

}
