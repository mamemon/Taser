package Taser.Ui.Gui.ActivityDisplayer.ActivityButton;

import java.awt.event.ActionListener;

import Taser.Workflow.SimpleActivity;
import Taser.WorkflowSimulator.WorkflowSimulatorLocalController;

public abstract class ActivityButtonListener implements ActionListener {

	/** The local controller */
	protected WorkflowSimulatorLocalController wslc;
	
	/** The activity to execute */
	protected SimpleActivity activity;

	/**
	 * @param wslc The local controller
	 * @param activity The activity
	 */
	public ActivityButtonListener(WorkflowSimulatorLocalController wslc, SimpleActivity activity) {
		super();
		this.wslc = wslc;
		this.activity = activity;
	}

	
	

}
