package Taser.Ui.Gui.ActivityDisplayer.ActivityButton;

import java.awt.event.ActionEvent;

import Taser.Workflow.SimpleActivity;
import Taser.WorkflowSimulator.WorkflowSimulatorLocalController;

public class ActivityButtonListenerTimeout extends ActivityButtonListener {

	public ActivityButtonListenerTimeout(WorkflowSimulatorLocalController wslc, SimpleActivity activity) {
		super(wslc, activity);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		this.wslc.timeout(this.activity);
	}

}
