package Taser.Ui.Gui.ActivityDisplayer;

import java.util.HashMap;
import java.util.Iterator;

import javax.swing.JPanel;

import Taser.Workflow.Activity;
import Taser.Workflow.ExclusiveChoice;
import Taser.Workflow.Flow;
import Taser.Workflow.Intern;
import Taser.Workflow.Invoke;
import Taser.Workflow.Receive;
import Taser.Workflow.Reply;
import Taser.Workflow.Sequence;
import Taser.Workflow.Meta;
import Taser.Workflow.SimpleActivity;
import Taser.Workflow.Visitor;

public class ActivityButtonWidth implements Visitor {

	/** The map containing the link between activities and their graphic representation */
	private HashMap<SimpleActivity, JPanel> map;
	
	/**
	 * Takes an activity and a map with all its graphics representation and return it graphics width
	 * @param activity The activity that we want to know the width
	 * @param map The map containing the link between activities and their graphic representation
	 * @return The graphics width of the given activity
	 */
	public static int activityButtonWidth(Activity activity, HashMap<SimpleActivity, JPanel> map){
		ActivityButtonWidth abw = new ActivityButtonWidth(map);
		return ((Integer)activity.accept(abw)).intValue();
	}
	
	
	
	
	
	/**
	 * @param map  The map containing the link between activities and their graphic representation
	 */
	public ActivityButtonWidth(HashMap<SimpleActivity, JPanel> map) {
		super();
		this.map = map;
	}

	@Override
	public Object visitActivity(Activity activity) {
		return activity.accept(this);
	}

	@Override
	public Object visitExclusiveChoice(ExclusiveChoice exclusiveChoice) {
		Integer thenWidth = (Integer) exclusiveChoice.getThenActivity().accept(this);
		Integer elseWidth = (Integer) exclusiveChoice.getElseActivity().accept(this);
		return new Integer(thenWidth.intValue() + elseWidth.intValue());
	}

	@Override
	public Object visitFlow(Flow flow) {
		int width = 0;
		Iterator<Activity> it = flow.getActivities();
		while(it.hasNext()){
			width += ((Integer)it.next().accept(this)).intValue();			
		}
		return new Integer(width);
	}

	@Override
	public Object visitIntern(Intern intern) {
		return new Integer(this.map.get(intern).getWidth());
	}

	@Override
	public Object visitInvoke(Invoke invoke) {
		return new Integer(this.map.get(invoke).getWidth());
	}

	@Override
	public Object visitReceive(Receive receive) {
		return new Integer(this.map.get(receive).getWidth());
	}

	@Override
	public Object visitReply(Reply reply) {
		return new Integer(this.map.get(reply).getWidth());
	}

	@Override
	public Object visitSequence(Sequence sequence) {
		int max = 0;
		Iterator<Activity> it = sequence.getActivities();
		while(it.hasNext()){
			max = Math.max(max, ((Integer)it.next().accept(this)).intValue());
		}
		return new Integer(max);
		
	}

	@Override
	public Object visitMeta(Meta meta) {
			int max = 0;
		
		return new Integer(max);	
	}

}
