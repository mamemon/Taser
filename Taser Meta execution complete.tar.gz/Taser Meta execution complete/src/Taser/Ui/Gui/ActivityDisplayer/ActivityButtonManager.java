package Taser.Ui.Gui.ActivityDisplayer;

import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import javax.swing.JPanel;

import Taser.Ui.Gui.GuiConfigConstants;
import Taser.Workflow.Activity;
import Taser.Workflow.ExclusiveChoice;
import Taser.Workflow.Flow;
import Taser.Workflow.Intern;
import Taser.Workflow.Invoke;
import Taser.Workflow.Receive;
import Taser.Workflow.Reply;
import Taser.Workflow.Sequence;
import Taser.Workflow.Meta;
import Taser.Workflow.SimpleActivity;
import Taser.Workflow.Variable;
import Taser.Workflow.Visitor;
import Taser.Workflow.WorkflowDepth;
import Taser.WorkflowSimulator.Pair;
import Taser.WorkflowSimulator.Triple;
import Taser.WorkflowSimulator.WorkflowSimulatorLocalController;

public class ActivityButtonManager implements Visitor {

	
	/** The layout in which button are putted */
	private ActivityButtonContainer panel;	

	/** current depth */
	private int currentDepth;
	
	/** current width */
	private int currentWidth;
		
	
	/** The map containing the link between activities and their graphic representation */
	private HashMap<SimpleActivity, JPanel> map;
	
	/** The variable number */
	private int variableNumber;
	
	





	public ActivityButtonManager(Activity activity, WorkflowSimulatorLocalController wslc, ActivityButtonContainer panel, HashMap<SimpleActivity, JPanel> map){
		
		this.panel = panel;
		this.map = map;
		this.currentDepth = 0;
		this.currentWidth = ActivityButtonWidth.activityButtonWidth(activity, map);
		variableNumber = 0;
		Iterator<Variable> itVariable = wslc.getVariables();
		while(itVariable.hasNext()){
			itVariable.next();
			variableNumber++;
		}
		
		
	}
	
	
	@Override
	public Object visitActivity(Activity activity) {
		return activity.accept(this);
	}

	@SuppressWarnings("unchecked")
	@Override
	public Object visitExclusiveChoice(ExclusiveChoice exclusiveChoice) {
		
		
		//Displaying if icon
		Rectangle rectBegin = this.placeComponent(new ImagePanel("images/choicesync.png"));
		
		//
		// Displaying sub-activities
		//
		currentDepth++;
		int saveDepth = this.currentDepth;
		//Place then activity
		int thenWidth = ActivityButtonWidth.activityButtonWidth(exclusiveChoice.getThenActivity(), map);
		currentWidth -=  thenWidth;
		Pair<Rectangle, Rectangle> pairThen = (Pair<Rectangle, Rectangle>) exclusiveChoice.getThenActivity().accept(this);
		
		//Place else activity
		currentWidth += thenWidth;
		int elseWidth = ActivityButtonWidth.activityButtonWidth(exclusiveChoice.getElseActivity(), map);
		currentWidth += elseWidth;
		Pair<Rectangle, Rectangle> pairElse = (Pair<Rectangle, Rectangle>) exclusiveChoice.getElseActivity().accept(this);
		
		//Returning
		currentWidth -= elseWidth;
		currentDepth = saveDepth + Math.max(WorkflowDepth.workflowDepth(exclusiveChoice.getThenActivity()), WorkflowDepth.workflowDepth(exclusiveChoice.getElseActivity()));
		
		
		Rectangle rectEnd = this.placeComponent(new ImagePanel("images/choicesync.png"));
		
		this.panel.addHorizontalVerticalLineOnActivation(rectBegin, pairThen.getFirst(), exclusiveChoice.getThenActivity());
		this.panel.addHorizontalVerticalLineOnActivation(rectBegin, pairElse.getFirst(), exclusiveChoice.getElseActivity());
		this.panel.addVerticalHorizontalLineOnFinish(pairThen.getSecond(), rectEnd,  exclusiveChoice.getThenActivity());
		this.panel.addVerticalHorizontalLineOnFinish(pairElse.getSecond(), rectEnd, exclusiveChoice.getElseActivity());
	
	
		
		
		return new Pair<Rectangle, Rectangle>(rectBegin, rectEnd);
	}

	@SuppressWarnings("unchecked")
	@Override
	public Object visitFlow(Flow flow) {
		Iterator<Activity> it = flow.getActivities();
		int flowWidth = ActivityButtonWidth.activityButtonWidth(flow, map);
		int maxDepth = 0;
		while(it.hasNext()){
			maxDepth = Math.max(maxDepth, WorkflowDepth.workflowDepth(it.next()));
		}
		it = flow.getActivities();
		int saveCurrentWidth = currentWidth;
		
		Rectangle rectBegin = this.placeComponent(new ImagePanel("images/flow.png"));
		
		currentWidth -= (flowWidth  / 2);
		currentDepth++;
		int saveDepth = this.currentDepth;
		
		ArrayList<Triple<Rectangle, Rectangle, Activity>> triples = new ArrayList<Triple<Rectangle, Rectangle, Activity>>();
		while(it.hasNext()){
			Activity activity = it.next();
			Pair<Rectangle, Rectangle> pair = (Pair<Rectangle, Rectangle>) activity.accept(this); 
			triples.add(new Triple(pair.getFirst(), pair.getSecond(), activity));
			currentWidth += ActivityButtonWidth.activityButtonWidth(activity, map);
		}
		
		//sync picture
		currentDepth = saveDepth + maxDepth;
		currentWidth = saveCurrentWidth;
		
		Rectangle rectEnd = this.placeComponent(new ImagePanel("images/flow.png"));
		Rectangle taserRectBegin = new Rectangle(rectBegin);
		Rectangle taserRectEnd = new Rectangle(rectEnd);
		
		
		for(Triple<Rectangle, Rectangle, Activity> triple : triples){
				
			this.panel.addHorizontalVerticalLineOnActivation(rectBegin, triple.getFirst(), triple.getThird());
			this.panel.addVerticalHorizontalLineOnFinish(triple.getSecond(), rectEnd, triple.getThird());
			
		}
		
		
		
		
		
		return new Pair<Rectangle, Rectangle>(taserRectBegin, taserRectEnd);
	}

	@Override
	public Object visitIntern(Intern intern) {
			Rectangle taserRect = new Rectangle(this.placeComponent(map.get(intern)));
			Label label = new Label();
			label.setSimpleActivity(intern);
			label.setX(taserRect.x);
			label.setY(taserRect.y +(int) taserRect.getHeight());
			this.panel.addLabelOnActivation(label);
			return new Pair<Rectangle, Rectangle>(taserRect, taserRect);
			
	}

	@Override
	public Object visitInvoke(Invoke invoke) {
		Rectangle taserRect = new Rectangle(this.placeComponent(map.get(invoke)));
		Label label = new Label();
		label.setSimpleActivity(invoke);
		label.setX(taserRect.x);
		label.setY(taserRect.y+ (int)taserRect.getHeight());
		this.panel.addLabelOnActivation(label);
		return new Pair<Rectangle, Rectangle>(taserRect, taserRect);
	}

	@Override
	public Object visitReceive(Receive receive) {
		Rectangle taserRect = new Rectangle(this.placeComponent(map.get(receive)));
		Label label = new Label();
		label.setSimpleActivity(receive);
		label.setX(taserRect.x);
		label.setY(taserRect.y+ (int)taserRect.getHeight());
		this.panel.addLabelOnActivation(label);
		return new Pair<Rectangle, Rectangle>(taserRect, taserRect);
	}

	@Override
	public Object visitReply(Reply reply) {
		Rectangle taserRect = new Rectangle(this.placeComponent(map.get(reply)));
		Label label = new Label();
		label.setSimpleActivity(reply);
		label.setX(taserRect.x);
		label.setY(taserRect.y + (int)taserRect.getHeight());
		this.panel.addLabelOnActivation(label);
		return new Pair<Rectangle, Rectangle>(taserRect, taserRect);
	}

	@SuppressWarnings("unchecked")
	@Override
	public Object visitSequence(Sequence sequence) {
		int saveCurrentDepth= this.currentDepth;
		Iterator<Activity> it = sequence.getActivities();
		Pair<Rectangle, Rectangle> pair = null;
		Rectangle rectBegin = null;
		Rectangle previousRect = null;
		while(it.hasNext()){
			Activity activity = it.next();
			pair = (Pair<Rectangle, Rectangle>) activity.accept(this);
			if(rectBegin==null){
				rectBegin = pair.getFirst();
				previousRect = pair.getSecond();
			}else{
				this.panel.addHorizontalVerticalLineOnActivation(previousRect, pair.getFirst(), activity);
				previousRect = pair.getSecond();
			}
			
			currentDepth++;
		}
		currentDepth = saveCurrentDepth;
		
		return new Pair<Rectangle, Rectangle>(rectBegin, pair.getSecond());
	}

	@SuppressWarnings("unchecked")
	@Override
	public Object visitMeta(Meta meta) {
		Pair<Rectangle, Rectangle> pair = null;
		Rectangle rectBegin = null;
		Rectangle previousRect = null;
		return new Pair<Rectangle, Rectangle>(rectBegin, pair.getSecond());
	}
	
	
	
	
	
	private Rectangle placeComponent(JPanel panel){
		int x = this.currentWidth - (panel.getWidth() /2);
		int y = this.currentDepth * (this.variableNumber * GuiConfigConstants.LINE_HEIGHT +  GuiConfigConstants.ACTIVITY_DISPLAYER_VERTICAL_SPACE);
		panel.setLocation(x, y);
//		panel.setBorder(new LineBorder(Color.black));
		this.panel.add(panel);		
		this.panel.validate();
		return panel.getBounds();
	}
	
	
}
