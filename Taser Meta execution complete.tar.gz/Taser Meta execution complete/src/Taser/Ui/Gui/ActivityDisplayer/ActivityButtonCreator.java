package Taser.Ui.Gui.ActivityDisplayer;

import java.awt.GridBagLayout;
import java.util.HashMap;
import java.util.Iterator;

import javax.swing.JPanel;

import Taser.Ui.Gui.ActivityDisplayer.ActivityButton.ActivityButtonFinish;
import Taser.Ui.Gui.ActivityDisplayer.ActivityButton.ActivityButtonNext;
import Taser.Ui.Gui.ActivityDisplayer.ActivityButton.ActivityButtonTimeout;
import Taser.Workflow.Activity;
import Taser.Workflow.ExclusiveChoice;
import Taser.Workflow.Flow;
import Taser.Workflow.Intern;
import Taser.Workflow.Invoke;
import Taser.Workflow.Receive;
import Taser.Workflow.Reply;
import Taser.Workflow.Sequence;
import Taser.Workflow.Meta;
import Taser.Workflow.SimpleActivity;
import Taser.Workflow.Visitor;
import Taser.WorkflowSimulator.WorkflowSimulatorLocalController;

public class ActivityButtonCreator implements Visitor {

	
	
	
	/** A map which makes a link between activities and graphical objects */
	private HashMap<SimpleActivity, JPanel> activitiesMap;
	
	/** A map which makes a link between finishables buttons and activities */
	private HashMap<SimpleActivity, ActivityButtonFinish> finishButtonsMap;
	
	/** A map which makes a link between activables buttons and activities */
	private HashMap<SimpleActivity, ActivityButtonNext> nextButtonsMap;
	
	/** A map which makes a link between timeoutables buttons and activities */
	private HashMap<SimpleActivity, ActivityButtonTimeout> timeoutButtonsMap;

	/** The local controller which is given to buttons, in order to execute activities */
	private WorkflowSimulatorLocalController wslc;
	
	
	
	
	
	/**
	 * @return A map which makes a link between activities and graphical objects
	 */
	public HashMap<SimpleActivity, JPanel> getActivitiesMap() {
		return activitiesMap;
	}


	/**
	 * @return A map which makes a link between finishables buttons and activities
	 */
	public HashMap<SimpleActivity, ActivityButtonFinish> getFinishButtonsMap() {
		return finishButtonsMap;
	}


	/**
	 * @return A map which makes a link between activables buttons and activities
	 */
	public HashMap<SimpleActivity, ActivityButtonNext> getNextButtonsMap() {
		return nextButtonsMap;
	}


	/**
	 * @return A map which makes a link between timeoutables buttons and activities
	 */
	public HashMap<SimpleActivity, ActivityButtonTimeout> getTimeoutButtonsMap() {
		return timeoutButtonsMap;
	}


	/**
	 * @param wslc The local controller which is given to buttons, in order to execute activities
	 */
	public ActivityButtonCreator(WorkflowSimulatorLocalController wslc) {
		super();
		this.activitiesMap = new HashMap<SimpleActivity, JPanel>();
		this.finishButtonsMap = new HashMap<SimpleActivity, ActivityButtonFinish>();
		this.nextButtonsMap = new HashMap<SimpleActivity, ActivityButtonNext>();
		this.timeoutButtonsMap = new HashMap<SimpleActivity, ActivityButtonTimeout>();
		this.wslc = wslc;
	}





	@Override
	public Object visitActivity(Activity activity) {
		return activity.accept(this);
	}

	@Override
	public Object visitExclusiveChoice(ExclusiveChoice exclusiveChoice) {
		exclusiveChoice.getThenActivity().accept(this);
		exclusiveChoice.getElseActivity().accept(this);
		return null;
	}

	@Override
	public Object visitFlow(Flow flow) {
		Iterator<Activity> it = flow.getActivities();
		while(it.hasNext()){
			it.next().accept(this);
		}
		return null;
	}

	@Override
	public Object visitIntern(Intern intern) {
		
		JPanel panel = new JPanel();
		panel.setVisible(true);
		panel.setOpaque(false);
		panel.setLayout(new GridBagLayout());
	
		ActivityButtonNext abn = new ActivityButtonNext(intern.getName(), "intern.gif", this.wslc, intern);
		abn.setSize(abn.getPreferredSize());
		
		panel.setSize(abn.getPreferredSize());
		
		panel.add(abn);
		
		this.activitiesMap.put(intern, panel);
		this.nextButtonsMap.put(intern, abn);
		
		return null;
	}

	@Override
	public Object visitInvoke(Invoke invoke) {
		
		JPanel panel = new JPanel();
		panel.setVisible(true);
		panel.setOpaque(false);
		panel.setLayout(new GridBagLayout());
	
		ActivityButtonNext abn = new ActivityButtonNext(invoke.getPartnerLink() + "::" + invoke.getName(), "intern.gif", this.wslc, invoke);
		abn.setSize(abn.getPreferredSize());
		
		ActivityButtonTimeout abt = new ActivityButtonTimeout("", "timeout.png", wslc, invoke);
		abt.setSize(abt.getPreferredSize());
		
		panel.setSize(abn.getSize().width + abt.getSize().width, abn.getSize().height + abt.getSize().height);
		panel.add(abt);
		panel.add(abn);
		
		this.activitiesMap.put(invoke, panel);
		this.nextButtonsMap.put(invoke, abn);
		this.timeoutButtonsMap.put(invoke, abt);
		
		return null;
	}

	@Override
	public Object visitReceive(Receive receive) {
		JPanel panel = new JPanel();
		panel.setVisible(true);
		panel.setOpaque(false);
		panel.setLayout(new GridBagLayout());
	
		ActivityButtonNext abn = new ActivityButtonNext(receive.getName(), "receive.gif", this.wslc, receive);
		abn.setSize(abn.getPreferredSize());
		
		ActivityButtonFinish abf = new ActivityButtonFinish("", "cancel-icon.gif", wslc, receive);
		abf.setSize(abf.getPreferredSize());
		
		panel.setSize(abn.getSize().width + abf.getSize().width, abn.getSize().height + abf.getSize().height);
		panel.add(abf);
		panel.add(abn);
		
		this.activitiesMap.put(receive, panel);
		this.nextButtonsMap.put(receive, abn);
		this.finishButtonsMap.put(receive, abf);
		
		return null;
	}

	@Override
	public Object visitReply(Reply reply) {
		JPanel panel = new JPanel();
		panel.setVisible(true);
		panel.setOpaque(false);
		panel.setLayout(new GridBagLayout());
	
		ActivityButtonNext abn = new ActivityButtonNext(reply.getName(), "send.gif", this.wslc, reply);
		abn.setSize(abn.getPreferredSize());
		
		panel.setSize(abn.getPreferredSize());
		
		panel.add(abn);
		
		this.activitiesMap.put(reply, panel);
		this.nextButtonsMap.put(reply, abn);
		
		return null;
	}

	@Override
	public Object visitSequence(Sequence sequence) {
		Iterator<Activity> it = sequence.getActivities();
		while(it.hasNext()){
			it.next().accept(this);
		}
		return null;
	}

	@Override
	public Object visitMeta(Meta meta) {
		return null;
	}
}
