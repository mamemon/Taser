package Taser.Ui.Gui.Toolbar.Action;

import java.awt.event.ActionEvent;

import Taser.WorkflowSimulator.WorkflowSimulatorLocalController;

public class StopSimulationAction extends ToolbarActionListener {

	public StopSimulationAction(WorkflowSimulatorLocalController wslc) {
		super(wslc);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		this.wslc.halt();

	}

}
