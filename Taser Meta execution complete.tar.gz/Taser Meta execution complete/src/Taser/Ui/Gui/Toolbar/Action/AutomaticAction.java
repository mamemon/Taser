package Taser.Ui.Gui.Toolbar.Action;

import java.awt.event.ActionEvent;

import Taser.WorkflowSimulator.WorkflowSimulatorLocalController;

public class AutomaticAction extends ToolbarActionListener {

	public AutomaticAction(WorkflowSimulatorLocalController wslc) {
		super(wslc);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		wslc.automaticExecution();
	}

}
	