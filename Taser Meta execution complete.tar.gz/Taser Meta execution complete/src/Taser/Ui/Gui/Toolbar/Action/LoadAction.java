package Taser.Ui.Gui.Toolbar.Action;

import java.awt.event.ActionEvent;

import javax.swing.JFileChooser;

import Taser.WorkflowSimulator.WorkflowSimulatorLocalController;

public class LoadAction extends ToolbarActionListener {

	public LoadAction(WorkflowSimulatorLocalController wslc) {
		super(wslc);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		JFileChooser chooser = new JFileChooser("./");
		int returnVal = chooser.showOpenDialog(null);
	    if(returnVal == JFileChooser.APPROVE_OPTION) {
	    	this.getWslc().loadActivityFromFile(chooser.getSelectedFile().getPath());
	    }

	}

}
