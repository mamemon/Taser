package Taser.Ui.Gui.Toolbar.Action;

import java.awt.event.ActionEvent;

import Taser.WorkflowSimulator.WorkflowSimulatorLocalController;

public class InteractiveAction extends ToolbarActionListener {
	
	
	public InteractiveAction(WorkflowSimulatorLocalController wslc) {
		super(wslc);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		wslc.interactiveExecution();
	}

}
