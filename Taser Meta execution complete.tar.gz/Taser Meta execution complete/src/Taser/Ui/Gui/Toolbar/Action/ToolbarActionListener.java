package Taser.Ui.Gui.Toolbar.Action;

import java.awt.event.ActionListener;

import Taser.WorkflowSimulator.WorkflowSimulatorLocalController;

public abstract class ToolbarActionListener implements ActionListener {

	/** The local controller */
	protected WorkflowSimulatorLocalController wslc;


	
	/**
	 * @param wslc
	 */
	public ToolbarActionListener(WorkflowSimulatorLocalController wslc) {
		super();
		this.wslc = wslc;

	}

	

	/**
	 * @param wslc the wslc to set
	 */
	public void setWslc(WorkflowSimulatorLocalController wslc) {
		this.wslc = wslc;
	}

	/**
	 * @return the wslc
	 */
	public WorkflowSimulatorLocalController getWslc() {
		return wslc;
	}

	
	
}
