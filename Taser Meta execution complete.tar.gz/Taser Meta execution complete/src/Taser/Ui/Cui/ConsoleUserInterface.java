package Taser.Ui.Cui;

import java.util.Iterator;

import Taser.Ui.WorkflowSimulatorUi;
import Taser.Workflow.SimpleActivity;
import Taser.WorkflowSimulator.WorkflowSimulatorLocalController;
import Taser.WorkflowSimulator.WorkflowSimulatorLocalController.SimulatorState;

/**
 * A simple console simulator user interface
 */
public class ConsoleUserInterface extends WorkflowSimulatorUi {

	
	//Attribute
	
	/** An iterator on activables activities */                
	private Iterator<SimpleActivity> activableIt;
	
	/** An iterator on blocked activities */
	private Iterator <SimpleActivity> blockedIt;
	
	/** An iterator on timeoutable activities */
	private Iterator<SimpleActivity> timeoutableIt;
	
	/** The current console thread */
	private ConsoleThread consoleThread;
	
	private static int updateCounter=0;
	
	//Constructor

	public ConsoleUserInterface(WorkflowSimulatorLocalController wslc) {
		super(wslc);
	       
		consoleThread = null;
		//Initial message
		System.out.println("Starting console mode");
		updateCounter+=1;
		help();
		//this.update();

		
	}

	//Getters
	
	/**
	 * @return the activableIt
	 */
	public Iterator<SimpleActivity> getActivableIt() {
		return activableIt;
	}

	
	/**
	 * @return the blockedIt
	 */
	public Iterator<SimpleActivity> getBlockedIt() {
		return blockedIt;
	}

	

	/**
	 * @return the timeoutableIt
	 */
	public Iterator<SimpleActivity> getTimeoutableIt() {
		return timeoutableIt;
	}
	  
	
	//Methods
	
	
	/**
	 * Print an help message
	 */
	public void help(){
		System.out.println("\nCurrent Taser configuration :\n------------------------------\n");
		System.out.println("UDDI server IP : " + wslc.getUDDIIp());
		System.out.println("Log file path : " + wslc.getLogFileName());
		System.out.println("\nAvailable commands :\n--------------------\n");
		System.out.println("load <filePath>: Load a workflow from an XML Bpel file, which path is <filePath>");
		System.out.println("Print the reseult : ");		
		System.out.println("setuddi <UDDI server ip>: Set the UDDI server IP");
		System.out.println("setlog <full filepath>: Set the name of the log file");
		if(this.wslc.getUpdateCurrentState() != SimulatorState.NOT_LOADED){
			System.out.println("interactive : Start an interactive simulation");
			System.out.println("auto : Start an automatic simulation");
		}
		System.out.println("help : Print this message");
		System.out.println("quit : Quit ;) ");
	}
	
	@Override
	public void printErrorMessage(String errorMessage) {
		System.err.println("\n*** [Error] " + errorMessage + "\n");
		System.err.flush();
		this.update();
		
		
	}

	public void printErrorMessageNoUpdate(String errorMessage) {
		System.err.println("\n*** [Error] " + errorMessage + "\n");
		System.err.flush();		
		
	}
	
	
	@Override
	public void printMessage(String message) {
		System.out.println(message);
		System.out.flush();
		//this.update();
	}
	

	@Override
	public void update(){
		//			System.out.println("I am in Update");
		//Updating datas
		this.activableIt = wslc.getActivablesActivities();
		this.blockedIt = wslc.getBlockedActivities();
		this.timeoutableIt = wslc.getTimeoutableActivities();

			
		/*if(this.consoleThread != null){
			this.consoleThread.interrupt();
			this.consoleThread = null;
		}*/
		
		//Switching to the right mode
		if(wslc.getUpdateCurrentState() == SimulatorState.INTERACTIVE){
			
			if (this.consoleThread instanceof InteractiveMode)
			this.consoleThread.run();
			else
			this.consoleThread = new InteractiveMode(this.wslc, this);
			

		}else if(wslc.getUpdateCurrentState() == SimulatorState.NOT_LOADED){
			//System.out.println("ConsoleUserInterface: SimulatorState.NOT_LOADED: Prompt ");
			if (this.consoleThread ==null)
				this.consoleThread = new Prompt(this.wslc, this);
			else this.consoleThread.run();
				
		}else if(wslc.getUpdateCurrentState() == SimulatorState.LOADED){
			
			//System.out.println("ConsoleUserInterface: SimulatorState.LOADED: Prompt ");

			if (this.consoleThread ==null)
			this.consoleThread = new Prompt(this.wslc, this);
			else this.consoleThread.run();
		

		}
		if(this.consoleThread != null){
			try{
			this.consoleThread.start();
			}catch(Exception e){}
		}
		
	}


		
	
	
	
	

	@Override
	public void loadActivity() {
		update();	
	}
	
	
	
	
	
}
