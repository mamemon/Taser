package Taser.Ui.Cui;

import java.util.Scanner;

import Taser.WorkflowSimulator.WorkflowSimulatorLocalController;
import Taser.WorkflowSimulator.WorkflowSimulatorLocalController.SimulatorState;

public class Prompt extends ConsoleThread {



	public Prompt(WorkflowSimulatorLocalController wslc, ConsoleUserInterface cui) {
		super(wslc, cui);
		//System.out.println("I am in Prompt");
	}

	@Override
	public void run() {
		boolean finished = false;
		while(!finished){
			finished = true;
			Scanner sc = new Scanner(System.in);
			System.out.print("\n> ");
			System.out.flush();
			String command = sc.nextLine();
			if(command.startsWith("load")){
				wslc.loadActivityFromFile(command.substring(command.indexOf(' ')+1));
			}else if(command.startsWith("setuddi")){
				wslc.setUDDIIp(command.substring(command.indexOf(' ')+1));
			}else if(command.startsWith("setlog")){
					wslc.setLogFileName(command.substring(command.indexOf(' ')+1));
			}else if(wslc.getUpdateCurrentState() == SimulatorState.LOADED && command.equals("interactive")){
						wslc.interactiveExecution();
			}else if(wslc.getUpdateCurrentState() == SimulatorState.LOADED && command.equals("auto")){
						wslc.automaticExecution();				
			}else if(command.equals("help")){
				this.cui.help();
				finished = false;
			}else if(command.equals("quit")){
				System.out.println("Good Bye!");
				this.wslc.quit();
			}else{
				this.cui.printErrorMessageNoUpdate("Wrong command, enter \"help\" to displays all commands.");
				finished = false;
			}
		}
		return;		
	}

}
