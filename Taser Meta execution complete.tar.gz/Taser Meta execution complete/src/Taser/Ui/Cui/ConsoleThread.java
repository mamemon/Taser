package Taser.Ui.Cui;

import Taser.WorkflowSimulator.WorkflowSimulatorLocalController;

public abstract class ConsoleThread extends Thread {

	protected WorkflowSimulatorLocalController wslc;
	
	protected ConsoleUserInterface cui;
	private static int nbConsole=0;
	
	public ConsoleThread(WorkflowSimulatorLocalController wslc, ConsoleUserInterface cui) {
		super();
		this.wslc = wslc;
		this.cui = cui;
		nbConsole+=1;
              //  System.out.println(nbConsole);
	}
	
	
	
	
	
	
	public abstract void run();
	
}
