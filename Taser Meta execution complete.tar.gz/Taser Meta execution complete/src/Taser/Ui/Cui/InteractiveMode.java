package Taser.Ui.Cui;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import Taser.Workflow.SimpleActivity;
import Taser.Workflow.Variable;
import Taser.WorkflowSimulator.WorkflowSimulatorLocalController;

public class InteractiveMode extends ConsoleThread {

	
	
	
	public InteractiveMode(WorkflowSimulatorLocalController wslc, ConsoleUserInterface cui) {
		super(wslc, cui);	
		
		
	}

	@Override
	public void run() {
		
		//Displaying variable status
		System.out.println("\nVariables status : \n__________________");
		Iterator<Variable> variables = this.wslc.getVariables();
		while(variables.hasNext()){
			Variable variable = variables.next();
			System.out.print("  "+variable.getName() + " : " );
			if(variable.isCorrupted()){
				System.out.println("corrupted !");
			}else{
				System.out.println("not corrupted !");
			}
		}
		
		
		//Browsing activables activities
		ArrayList<SimpleActivity> act = new ArrayList<SimpleActivity>();
		while(cui.getActivableIt().hasNext()){
			act.add(cui.getActivableIt().next());
		}
		if(act.size()>0){
			System.out.println("\n\nThere are " + act.size() + " activables activities : ");
			System.out.print("__________");
			for(int i = 0; i < act.size(); i++){
				System.out.print("_");
			}
			System.out.println("________________________");
			for(int i = 0; i < act.size(); i++){
				System.out.println("  " + i + ")" + act.get(i).getName());
			}
		}
		
		//Browsing blocked activities
		ArrayList<SimpleActivity> blockedAct = new ArrayList<SimpleActivity>();
		while(cui.getBlockedIt().hasNext()){
			blockedAct.add(cui.getBlockedIt().next());
		}
		if(blockedAct.size()>0){
			System.out.println("\nThere are "+ blockedAct.size() + " blocked activities. You can force them to finish :");
			System.out.print("__________");
			for(int i = 0; i < blockedAct.size(); i++){
				System.out.print("_");
			}
			System.out.println("__________________________________________________");
			for(int i = 0; i < blockedAct.size(); i ++){
				System.out.println("  " + (i + act.size()) + ")" + blockedAct.get(i).getName());
			}
			
		}
		
		//Browsing timeoutable activities
		ArrayList<SimpleActivity> timeoutableAct = new ArrayList<SimpleActivity>();
		while(this.cui.getTimeoutableIt().hasNext()){
			timeoutableAct.add(this.cui.getTimeoutableIt().next());
		}
		if(timeoutableAct.size() > 0){
			System.out.println("\nThere are " + timeoutableAct.size() + " blocked and timeoutable activities. You can timeout them to finish :");
			System.out.print("__________");
			for(int i = 0; i < timeoutableAct.size(); i++){
				System.out.print("_");
			}
			System.out.println("_____________________________________________________________________");			
			
			for(int i = 0; i < timeoutableAct.size(); i++){
				System.out.println("  " + (i+ act.size()+ blockedAct.size()) + ")" + timeoutableAct.get(i).getName());
			}
		}
		
		
		System.out.println("\n Type -1 in order to change some variable status");
		boolean rightNumber = false;
		int number = -1;
		while(!rightNumber){
			Scanner sc = new Scanner(System.in);
			System.out.print("-- Please enter the operation's number you want to execute : ");
			try{
				number = sc.nextInt();
			}catch(Exception e){}
			if(number >= -1 && number < (act.size() + blockedAct.size() + timeoutableAct.size())){
				rightNumber = true;					
			}
		}
		

		try {
			if(number >= 0){
				if(number < act.size()){
					wslc.next(act.get(number));
				}else if(number < act.size() + blockedAct.size()){
					number = number - act.size();
					wslc.finish(blockedAct.get(number - act.size()));
				}else{
					wslc.timeout(timeoutableAct.get(number - (act.size() + blockedAct.size())));
				}
			}else{
				this.changeVariableStatus();				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * A prompt which allow to change some variable status
	 */
	private void changeVariableStatus() {
		System.out.println("\n\nSwitch variable status : \n_________________________");
		Iterator<Variable> it = this.wslc.getVariables();
		ArrayList<Variable> variables = new ArrayList<Variable>();
		while(it.hasNext()){
			variables.add(it.next());
		}
		
		
		for(int i=0; i < variables.size(); i++){
			System.out.print(i + "] " + variables.get(i) + " : "  );
			if(variables.get(i).isCorrupted()){
				 System.out.println("corrupted!");
			}else{
				System.out.println("not corrupted!");
			}
		}
		System.out.println("Type -1 in order to return to activities list");
		boolean rightNumber = false;
		int number = -1;
		while(!rightNumber){
			Scanner sc = new Scanner(System.in);
			System.out.print("-- Please enter the variable's number you want to change the status: ");
			try{
				number = sc.nextInt();
			}catch(Exception e){}
			if(number >= -1 && number < variables.size()){
				rightNumber = true;					
			}
		}
		if(number != -1){
			variables.get(number).setCorrupted(!variables.get(number).isCorrupted());
		}		
		this.wslc.notif();
		
	}

}
