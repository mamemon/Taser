package Taser.Ui;


/**
 * Interface Observable
 * 
 */


public interface WorkflowSimulatorObservable {

	/** 
	 * Permet l'ajout d'un Observer a l'objet observable. Voir le design pattern Observer 
	 * @param workflowSimulatorUi Observer observant l'observable :)
	 */
	
	public void add(WorkflowSimulatorUi workflowSimulatorUi);
	
	/**	
	 * Provoque un update sur tous les observers qui sont lies a this
	 */
	
	public void notif();
	
	
}
