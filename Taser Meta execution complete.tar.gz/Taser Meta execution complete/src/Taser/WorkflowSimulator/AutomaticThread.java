package Taser.WorkflowSimulator;

import java.util.ArrayList;
import java.util.Iterator;

import Taser.Workflow.SimpleActivity;
import Taser.WorkflowSimulator.WorkflowSimulatorLocalController.SimulatorState;

/**
 * Threaded automatic mode
 */
public class AutomaticThread extends Thread {

	private WorkflowSimulatorLocalController wslc;
	
	public AutomaticThread(WorkflowSimulatorLocalController wslc){
		this.wslc = wslc;
	}
	
	public void run(){
		Iterator<SimpleActivity> activableIt = this.wslc.getActivablesActivities();
		while(this.wslc.getUpdateCurrentState() == SimulatorState.AUTOMATIC){
			ArrayList<SimpleActivity> act = new ArrayList<SimpleActivity>();
			while(activableIt.hasNext()){
				act.add(activableIt.next());
			}
			int number = (int)(Math.random()*(act.size()));
			if(act.size() != 0){ 
				this.wslc.next(act.get(number));		
			}
			activableIt = this.wslc.getActivablesActivities();
		}
	}
	
	
}
