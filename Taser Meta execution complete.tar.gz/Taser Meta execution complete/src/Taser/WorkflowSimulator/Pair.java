package Taser.WorkflowSimulator;

/**
 * This is a Pair class which contain two objects of differents types. 
 * @param <T> Type of the pair's first element 
 * @param <S> Type of the pair's second element
 */


public class Pair<T, S> {

	/** Pair's first element*/
	private T first;
	
	/** Pair's second element*/
	private S second;
	
	
	/*
	 * Constructors 
	 */
	/**
	 * Default constructor, it sets fields to null.
	 */
	public Pair(){
		super();
		first = null;
		second = null;
	}
	
	/**
	 * Constructors settings fields with the given objects
	 * @param first The pair's first element to set
	 * @param second The pair's second element to set
	 */
	public Pair(T first,S second){
		super();
		this.first = first;
		this.second = second;
	}

	/**
	 * @return the pair's first element
	 */
	public T getFirst() {
		return first;
	}

	/**
	 * @param first the pair's first element to set
	 */
	public void setFirst(T first) {
		this.first = first;
	}

	/**
	 * @return the pair's second element
	 */
	public S getSecond() {
		return second;
	}

	/**
	 * @param second the pair's second element to set
	 */
	public void setSecond(S second) {
		this.second = second;
	}
	
	
	
	
}
