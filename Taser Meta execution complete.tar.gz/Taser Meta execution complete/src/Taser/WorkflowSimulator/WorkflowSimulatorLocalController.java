package Taser.WorkflowSimulator;

import java.rmi.RemoteException;
import java.util.Iterator;


import Taser.Ui.WorkflowSimulatorObservable;
import Taser.Workflow.*;

/**
 * Provides local methods in order to execute simple activity in a local controller.
 */

public interface WorkflowSimulatorLocalController extends  WorkflowSimulatorObservable{
	
	
	
	
	
	public static enum SimulatorState{
		NOT_LOADED,
		LOADED,
		INTERACTIVE,
		AUTOMATIC
	}

	
	
	/**
	 * Return the previous state of the simulator
	 * @return Return the previous state of the simulator
	 */
	public SimulatorState getUpdatePreviousState();
	
	/**
	 * Return the current state of the simulator
	 * @return Return the current state of the simulator
	 */
	public SimulatorState getUpdateCurrentState();
	
	
	/**
	 * Launch an automatic execution. When there is a choice between severals activities, the control chose one at random.
	 */
	public void automaticExecution();
	
	/**
	 * Stop the current simulation, erase all simulations datas and put the controller to the loaded state
	 */
	public void halt();
	
	
	/**
	 * Launch an interactive execution
	 */
	public void interactiveExecution();
	
	
	
	/**
	 * Execute the given Intern activity
	 * @param intern The intern to be executed
	 */
	public void executeIntern(Intern intern);
	
	
	
	/**
	 * Execute the given Invoke activity
	 * @param invoke The invoke to be executed
	 */
	public void executeInvoke(Invoke invoke);
	public void executeFinInvoke(Invoke invoke);
	
	/**
	 * Execute the given Receive activity
	 * @param receive The receive to be executed
	 */
	public void executeReceive(Receive receive);
	
	/**
	 * Execute the given Reply activity
	 * @param reply The reply to be executed
	 */
	public void executeReply(Reply reply);
	
	
	/**
	 * Return an iterator on all activables activities of the controlled workflow
	 * @return an iterator on all activables activities of the controlled workflow
	 */
	public Iterator<SimpleActivity> getActivablesActivities();
	
	
	/**
	 * Return an iterator on all blocked activities of the controlled workflow
	 * @return an iterator on all blocked activities of the controlled workflow
	 */
	public Iterator<SimpleActivity> getBlockedActivities();
	
	
	/**
	 * Return an iterator on all timeoutable activities of the controlled workflow
	 * @return an iterator on all timeoutable activities of the controlled workflow 
	 */
	public Iterator<SimpleActivity> getTimeoutableActivities();
	
	

	public boolean isActivityFinished(Activity activity);
	
	

	public boolean isActivityActivated(Activity activity);
	
	
	/**
	 * Return an iterator on all workflow's variable
	 * @return an iterator on all workflow's variable
	 */
	public Iterator<Variable> getVariables();
	
	/**
	 * Return the controlled activity
	 * @return the controlled activity
	 */
	public Activity getActivity();
	
	
	
	
	/**
	 * Load a workflow from a XML BPEL file
	 * @param filePath The xml BPEL file
	 * @return 
	 * @throws IOException 
	 * @throws JDOMException 
	 */
	public void loadActivityFromFile(String filePath);
	
	

	
	/**
	 * In order to quit
	 */
	public void quit();
	
	/*
	 * 
	 * Activity proccessing
	 * 
	 * 
	 */
	
	
	
	/**
	 * Execute a timeout on the Activity activity
	 * @param activity The activity which will be timouted
	 */
	public void timeout(SimpleActivity activity);
	
	
	/**
	 * Finished an activity which was waiting for a remote request/response
	 * @param activitity  The activity to finish
	 */
	public void finish(SimpleActivity activitity);
	
	/**
	 * Execute the Activity activity in the workflow. If activity is not executable, because it isn't the next activity in the workflow, then nothing
	 * is done.
	 * @param activity The activity to be executed
	 */
	public void next(SimpleActivity activity);
	
		
	
	
	/**
	 * Restart the workflow simulation from the begining. It end the current activity simulation, go back to the first
	 * activity and restore workflow's initial state . All datas, transactions, are deleted...	 * 
	 */
	public void restart() throws RemoteException;
	
	
	
	/*
	 * Configuration
	 */
	
	/**
	 * In order to set the uddi IP (which is localhost by default) 
	 * @param ip The UDDI ip
	 */
	public void setUDDIIp(String ip);
	
	/**
	 * Return the current UDDI ip (which is localhost by default)
	 * @return the current UDDI ip
	 */
	public String getUDDIIp();
	
	
	/**
	 * In order to change the complete name of the log file (which is ./log by default)
	 * @param logFileName The new complete and full name of the log file
	 */
	public void setLogFileName(String logFileName);
	
	
	/**
	 * Return the current full name of the log file (which is ./log by default)
	 * @return the current full name of the log file
	 */
	public String getLogFileName();
	
}
