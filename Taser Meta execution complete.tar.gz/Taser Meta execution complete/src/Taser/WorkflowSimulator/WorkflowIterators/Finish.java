package Taser.WorkflowSimulator.WorkflowIterators;

import java.util.Iterator;

import Taser.Workflow.Invoke;
import Taser.Workflow.SimpleActivity;
import Taser.Workflow.Intern;

public class Finish implements WorkflowIteratorVisitor {
	/** The activity to finish */
	private SimpleActivity activity;
	
	public static void finish(ActivityIterator activityIterator, SimpleActivity activity){
		Finish finish = new Finish();
		finish.activity = activity;
		activityIterator.accept(finish);
	}
	
	
	@Override
	public Object visitFlowIterator(FlowIterator flowIterator) {
		//System.out.println("on regarde si le flot est termin�");
		Iterator<ActivityIterator> it = flowIterator.getActivities();
		while(it.hasNext()){
			
			ActivityIterator tmp = it.next();
			//System.out.println("on traite un element du flot "+tmp.activity.getName());
			if(Contains.contains(tmp, activity)){
				//System.out.println("on est entre");
				tmp.accept(this);
			}
		}	
		return null;
	}

	@Override
	public Object visitIfIterator(IfIterator ifIterator) {
		if(ifIterator.isThenEnabled()){
			ifIterator.getThenIterator().accept(this);
		}
		if(ifIterator.isElseEnabled()){
			ifIterator.getElseIterator().accept(this);
		}
		
		return null;
	}

	@Override
	public Object visitInternIterator(InternIterator internIterator) {
		if(internIterator.getActivity() == this.activity){
			internIterator.setFinished(true);
		}
		return null;
	}

	@Override
	public Object visitInvokeIterator(InvokeIterator invokeIterator) {
		if(invokeIterator.getActivity() == this.activity){
			//System.out.println("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
			//System.out.println("Finis :: appel de finish pour visit invodkeiterator");
			invokeIterator.setFinished(true);
			if(((Invoke) invokeIterator.getActivity()).isSync()){
				invokeIterator.wsc.executeFinInvoke(((Invoke) invokeIterator.getActivity()));
			}
		}	
		return null;
	}

	@Override
	public Object visitReceiveIterator(ReceiveIterator receiveIterator) {
		//System.out.println("Finish::visitReceiveIterator");
		if(receiveIterator.getActivity() == this.activity){
			//System.out.println("indique que le receive est termin�");
			receiveIterator.setFinished(true);
		}
		return null;
	}

	@Override
	public Object visitReplyIterator(ReplyIterator replyIterator) {
		if(replyIterator.getActivity() == this.activity){
			replyIterator.setFinished(true);
		}
		return null;
	}

	@Override
	public Object visitSequenceIterator(SequenceIterator sequenceIterator) {
		//System.out.println("DEBUT Finish::visitSequenceIterator");
		ActivityIterator currentElement = sequenceIterator.getCurrentElement();
		//System.out.println("elment courant "+ currentElement.activity.getName());		
		Iterator<ActivityIterator> activitiesIterator = sequenceIterator.getActivitiesIterator();
		
		/*System.out.println("affichage de l'iterateur");
		Iterator<ActivityIterator> i = sequenceIterator.getActivitiesIterator();
		while (i.hasNext()){
			ActivityIterator ai=i.next();
			System.out.println("element de l'iterateur "+ai.activity.getName());			
		}*/
		
		//System.out.println("on regarde si l'element courant est fini");
		//System.out.println("activite racine de l'iterateur "+ currentElement.getActivity().getName());
		if (currentElement instanceof SequenceIterator) System.out.println("element courant "+((SequenceIterator)currentElement).getCurrentElement().getActivity().getName());
		if(!IsFinished.isFinished(currentElement)){
			//System.out.println("il n'est pas fini, on termine l'activit� suivante");
			Finish.finish(currentElement, activity);
			//if (currentElement instanceof FlowIterator) ((FlowIterator)currentElement).afficheActivities();
			//if(activitiesIterator.hasNext()){
				//ActivityIterator ai=activitiesIterator.next(); L'erreur vient de cette ligne
				//ActivityIterator ai=Next.
				//System.out.println("element suivant "+ai.activity.getName());
				//sequenceIterator.setCurrentElement(ai);
			//}else{
			if (IsFinished.isFinished(currentElement)){
				//System.out.println("l'element courant est termin�");
				if (activitiesIterator.hasNext()){
					sequenceIterator.setCurrentElement(activitiesIterator.next());
				} else {
					//System.out.println("les activites sont terminees");
					sequenceIterator.setFinished(true);
				}
			}
		}
		//System.out.println("FIN Finish::visitSequenceIterator");
		return null;
	}

	@Override
	public Object visitMetaIterator(MetaIterator metaIterator) {
		//System.out.println("DEBUT Finish::visitSequenceIterator");
		
		return null;
	}

}
