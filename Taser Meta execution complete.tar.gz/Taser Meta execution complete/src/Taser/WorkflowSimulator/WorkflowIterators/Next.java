package Taser.WorkflowSimulator.WorkflowIterators;

import java.util.Iterator;

import Taser.Workflow.*;
import Taser.WorkflowSimulator.WorkflowSimulatorLocalController;
import Taser.WorkflowSimulator.WorkflowSimulatorController;

/**
 * Execute the visited activity
 * 
 */
public class Next implements WorkflowIteratorVisitor {
	
	/** The activity we want to execute */
	private SimpleActivity activity;
	
	/** The worflow local controller */
	private WorkflowSimulatorLocalController wsc;
	
	
	public static void next(SimpleActivity activity, WorkflowSimulatorLocalController wsc, ActivityIterator activityIterator){
		//System.out.println("Next :: next pour l'activite "+ activity.getName() + "et l'iterateur associ� a l'activite "+ activityIterator.getActivity().getName());
		Next next = new Next();
		next.activity = activity;
		next.wsc = wsc;
		activityIterator.accept(next);
	}
	
	
	
	/*
	 *  Visitor methods
	 */
	
	
	
	
	@Override
	public Object visitFlowIterator(FlowIterator flowIterator) {
		//System.out.println("Next:: visite de l'iterateur flow "+ flowIterator.activity.getName());
		//System.out.println("Next::vivitFlowIterator debut fonction");
		Iterator<ActivityIterator> it = flowIterator.getActivities();
		while(it.hasNext()){
			ActivityIterator tmp = it.next();
			//System.out.println("Next::visitFlowIterator traitement d'un activityIterator");
			if(Contains.contains(tmp, this.activity)){
				tmp.accept(this);
			}
		}
		//System.out.println("Next::vivitFlowIterator fin fonction");
		//System.out.println("Next :: Fin visite de la flow "+ flowIterator.activity.getName());
		return null;
	}

	
	
	
	@Override
	public Object visitIfIterator(IfIterator ifIterator) {
		System.out.println("Next::IF");
		//For the first activation
		if(ifIterator.isThenEnabled() && ifIterator.isElseEnabled()){
			if(Contains.contains(ifIterator.getThenIterator(), this.activity)){
				ifIterator.setElseEnabled(false);
			}else{
				ifIterator.setThenEnabled(false);
			}
		}
		
		
		if(ifIterator.isThenEnabled()){
			ifIterator.getThenIterator().accept(this);			
		}else{
			ifIterator.getElseIterator().accept(this);
		}
		
		return null;
	}

	
	
	
	
	@Override
	public Object visitInvokeIterator(InvokeIterator invokeIterator) {
		//System.out.println("visite de l'iterateur invoke "+ invokeIterator.activity.getName());
		////System.out.println("Next::visitiInvokeIterator::debut");
		if(invokeIterator.getActivity()==activity){
			////System.out.println("c'est la bonne activit�");
			if(((Invoke) invokeIterator.getActivity()).isSync()){
				////System.out.println("oh oh je suis synchrone... voila qui n'est pas normal");
				if(!invokeIterator.isHasBeenExecuted()){
					invokeIterator.setFinished(false);
					invokeIterator.setHasBeenExecuted(true);
					this.wsc.executeInvoke((Invoke)invokeIterator.getActivity());	
				}
			}else{
				////System.out.println("comme invoke asynchrone on l'execute et on passe a la suite");
				invokeIterator.setFinished(true);
				invokeIterator.setHasBeenExecuted(true);
				this.wsc.executeInvoke((Invoke)invokeIterator.getActivity());
			}
						
		}	
		////System.out.println("Next::visitiInvokeIterator::fin");
		//System.out.println("Fin visite de la invoke "+ invokeIterator.activity.getName());
		return null;
	}

	@Override
	public Object visitReceiveIterator(ReceiveIterator receiveIterator) {
		//System.out.println("visite de l'iteratuer receive "+ receiveIterator.activity.getName());
		if(receiveIterator.getActivity()==activity){
			if(!receiveIterator.isHasBeenExecuted()){
				receiveIterator.setHasBeenExecuted(true);
				receiveIterator.setFinished(false); //Lolo je modifie par true auquel cas l'enchainement se passe bien mais plus l'attente de la requete
				this.wsc.executeReceive((Receive)receiveIterator.getActivity());	
			} 
						
		}
		//System.out.println("Fin de la visite de la receive "+ receiveIterator.activity.getName());
		/*ActivityIterator i = ((WorkflowSimulatorController)this.wsc).activityIterator;
		System.out.println("iterateur du wsc "+i.activity.getName());
		if (i instanceof SequenceIterator) {
			ActivityIterator ec=((SequenceIterator)i).getCurrentElement();
			System.out.println("element courant "+ec.activity.getName());
			if (ec instanceof FlowIterator){
				ActivityIterator es=((FlowIterator)ec).getActivities().next();
				System.out.println("element courant du flot "+ es.activity.getName());
				if (es instanceof SequenceIterator) {
					ActivityIterator ess=((SequenceIterator)es).getCurrentElement();
					System.out.println("element courant de la deuxieme seq "+ess.activity.getName());
				}
			}
		}*/
		
		return null;
	}

	@Override
	public Object visitInternIterator(InternIterator internIterator) {
		System.out.println("Next::Intern");
		//System.out.println("visite de l'iterateur interne "+ internIterator.activity.getName());
		//System.out.println("internIterator.getActivity() "+ internIterator.getActivity());
		if(internIterator.getActivity()==activity && !internIterator.isHasBeenExecuted()){
			internIterator.setHasBeenExecuted(true);
			internIterator.setFinished(true);
			this.wsc.executeIntern((Intern)internIterator.getActivity());			
		}		
		//System.out.println("Fin visite de la interne "+ internIterator.activity.getName());
		return null;
	}



	@Override
	public Object visitReplyIterator(ReplyIterator replyIterator) {
		System.out.println("DEBUT Next::visitReplyOperator");
		if(replyIterator.getActivity()==activity){
			if(!replyIterator.isHasBeenExecuted()){
				replyIterator.setHasBeenExecuted(true);
				replyIterator.setFinished(true);
				System.out.println("Next::visitReplyIterator pour l'activite " + replyIterator.getActivity().getName());
				this.wsc.executeReply((Reply)replyIterator.getActivity());	
			}
						
		}
		System.out.println("FIN Next::visitReplyOperator");
		return null;
	}

	@Override
	public Object visitSequenceIterator(SequenceIterator sequenceIterator) {
		System.out.println("Next::Sequence");
		//System.out.println("Next:: visite de l'iterateur sequence "+ sequenceIterator.activity.getName());
		ActivityIterator a = sequenceIterator.getCurrentElement();
		//System.out.println("active courante dans la sequence: "+a.activity.getName());
		a.accept(this);
		//System.out.println("activeIterortFin "+a.activity.getName());
		if(IsFinished.isFinished(sequenceIterator.getCurrentElement())){
			//System.out.println("l'activite courante de la seq est termin�e, on calcule la suivante");
			if(sequenceIterator.getActivitiesIterator().hasNext()){
				//System.out.println("super il reste encore une activite dans la sequence");
				sequenceIterator.setCurrentElement(sequenceIterator.getActivitiesIterator().next());
			}else{
				//System.out.println("ouie ma sequence est termin�e");
				sequenceIterator.setFinished(true);				
			}
		}
		//System.out.println("Fin visite de la sequence "+ sequenceIterator.activity.getName());
		return null;
	}
	
	@Override
	public Object visitMetaIterator(MetaIterator metaIterator) {
		System.out.println("Next::Meta");
		//System.out.println("Next:: visite de l'iterateur Meta "+ metaIterator.activity.getName());
		SimpleActivityIterator a;
		//System.out.println("active courante dans la sequence: "+a.activity.getName());
		
		if (metaIterator.getCurrentElement().getActivity()==activity)
			{
				a = metaIterator.getCurrentElement();
				a.accept(this);
				metaIterator.setFinished(true);
				metaIterator.setHasBeenExecuted(true);
			}
		else 
			{
				
				if(metaIterator.getActivitiesIterator().hasNext()){

				metaIterator.setCurrentElement(metaIterator.getActivitiesIterator().next());
			
				if (metaIterator.getCurrentElement().getActivity()==activity)
					{
						a = metaIterator.getCurrentElement();
						a.accept(this);
						metaIterator.setFinished(true);
						metaIterator.setHasBeenExecuted(true);
					}
				}
				metaIterator.setFinished(true);
			}


		//a.accept(this);
		//System.out.println("activeIterortFin "+a.activity.getName());
	/*	if(IsFinished.isFinished(metaIterator.getCurrentElement())){
			//System.out.println("l'activite courante de la seq est termin�e, on calcule la suivante");
			if(metaIterator.getActivitiesIterator().hasNext()){
				//System.out.println("super il reste encore une activite dans la sequence");
				metaIterator.setCurrentElement(metaIterator.getActivitiesIterator().next());
			}else{
				//System.out.println("ouie ma sequence est termin�e");
				metaIterator.setFinished(true);				
			}
		}*/
		//System.out.println("Fin visite de la sequence "+ sequenceIterator.activity.getName());
		return null;
	}

}
