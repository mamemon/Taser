package Taser.WorkflowSimulator.WorkflowIterators;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import Taser.Workflow.SimpleActivity;

public class GetTimeoutable implements WorkflowIteratorVisitor {


	@SuppressWarnings("unchecked")
	public static Collection<SimpleActivity> getTimeoutable(ActivityIterator activityIterator){
		GetTimeoutable getTimeoutable = new GetTimeoutable();
		if(activityIterator != null){
			return (Collection<SimpleActivity>) activityIterator.accept(getTimeoutable);
		}else{
			return new ArrayList<SimpleActivity>();
		}
	}
	
	
	@SuppressWarnings("unchecked")
	@Override
	public Object visitFlowIterator(FlowIterator flowIterator) {
		Collection<SimpleActivity> activables = new ArrayList<SimpleActivity>();
		Iterator<ActivityIterator> it = flowIterator.getActivities();
		while(it.hasNext()){
			activables.addAll((Collection<SimpleActivity>) it.next().accept(this));
		}
		return activables;
	}
	
	

	@SuppressWarnings("unchecked")
	@Override
	public Object visitIfIterator(IfIterator ifIterator) {
		Collection<SimpleActivity> activables = new ArrayList<SimpleActivity>();
		if(ifIterator.isThenEnabled()){
			activables.addAll(((Collection<SimpleActivity>)ifIterator.getThenIterator().accept(this)));
		}
		if(ifIterator.isElseEnabled()){
			activables.addAll(((Collection<SimpleActivity>)ifIterator.getElseIterator().accept(this)));
		}
		return activables;
	}

	@Override
	public Object visitInternIterator(InternIterator internIterator) {
		return new ArrayList<SimpleActivity>();		
	}

	@Override
	public Object visitInvokeIterator(InvokeIterator invokeIterator) {
			Collection<SimpleActivity> result = new ArrayList<SimpleActivity>();
			if(!invokeIterator.isFinished()&&invokeIterator.isHasBeenExecuted()){
				result.add((SimpleActivity)invokeIterator.getActivity());
			}
			
			return result;
	}

	@Override
	public Object visitReceiveIterator(ReceiveIterator receiveIterator) {
		return new ArrayList<SimpleActivity>();	
	}

	@Override
	public Object visitReplyIterator(ReplyIterator replyIterator) {
		return new ArrayList<SimpleActivity>();			
	}

	@Override
	public Object visitSequenceIterator(SequenceIterator sequenceIterator) {
		if(!sequenceIterator.getFinished()){	
			return sequenceIterator.getCurrentElement().accept(this);
		}else{
			return new ArrayList<SimpleActivity>();
		}
	}

	@Override
	public Object visitMetaIterator(MetaIterator metaIterator) {
		if(!metaIterator.isFinished()){	
			return metaIterator.getCurrentElement().accept(this);
		}else{
			return new ArrayList<SimpleActivity>();
		}
	}

}
