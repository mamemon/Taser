package Taser.WorkflowSimulator.WorkflowIterators;

import Taser.Workflow.Activity;
import Taser.WorkflowSimulator.WorkflowSimulatorLocalController;

public class ReceiveIterator extends SimpleActivityIterator {

	public ReceiveIterator(Activity activity, WorkflowSimulatorLocalController wsc) {
		super(activity, wsc);		
	}

	

	@Override
	public Object accept(WorkflowIteratorVisitor wiv) {
		return wiv.visitReceiveIterator(this);
	}

	

}

	

