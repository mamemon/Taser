package Taser.WorkflowSimulator.WorkflowIterators;

import Taser.Workflow.Activity;
import Taser.WorkflowSimulator.WorkflowSimulatorLocalController;

class InvokeIterator extends SimpleActivityIterator {
	
	
	
	public InvokeIterator(Activity activity, WorkflowSimulatorLocalController wsc) {
		super(activity, wsc);
		this.hasBeenExecuted = false;
		this.finished = false;
	}

	

	@Override
	public Object accept(WorkflowIteratorVisitor wiv) {
		return wiv.visitInvokeIterator(this);
	}

		
	
	

}
