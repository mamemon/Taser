package Taser.WorkflowSimulator.WorkflowIterators;

public interface WorkflowIteratorVisitor {
	
	public Object visitFlowIterator(FlowIterator flowIterator);
	
	public Object visitIfIterator(IfIterator ifIterator);
	
	public Object visitInternIterator(InternIterator internIterator);
	
	public Object visitInvokeIterator(InvokeIterator invokeIterator);
	
	public Object visitReceiveIterator(ReceiveIterator receiveIterator);
	
	public Object visitReplyIterator(ReplyIterator replyIterator);
	
	public Object visitSequenceIterator(SequenceIterator sequenceIterator);
	
	public Object visitMetaIterator(MetaIterator metaIterator);
	
	
}
