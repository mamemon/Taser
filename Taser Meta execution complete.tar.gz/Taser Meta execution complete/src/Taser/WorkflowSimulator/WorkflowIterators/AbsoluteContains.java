package Taser.WorkflowSimulator.WorkflowIterators;


import java.util.Iterator;

import Taser.Workflow.Activity;

public class AbsoluteContains implements WorkflowIteratorVisitor {

	private Activity activity;
	
	/**
	 * Returns true if this Activity contains the specified activity
	 * @param activity Activity whose presence in this Activity is to be tested.
	 * @param activityIterator The activity iterator in which you are searching activity
	 * @return true if the tested activity contains the specified activity
	 */
	public static boolean absoluteContains(ActivityIterator activityIterator, Activity activity){
		AbsoluteContains absoluteContains = new AbsoluteContains();
		absoluteContains.activity = activity;
		return ((Boolean)activityIterator.accept(absoluteContains)).booleanValue();
	}
	
	@Override
	public Object visitFlowIterator(FlowIterator flowIterator) {
		Iterator<ActivityIterator> it = flowIterator.getActivities();
		while(it.hasNext()){
			if(((Boolean)it.next().accept(this)).booleanValue()){
				return new Boolean(true);
			}
		}
		return new Boolean(false);
	}

	@Override
	public Object visitIfIterator(IfIterator ifIterator) {
		return new Boolean(
				((Boolean)ifIterator.getThenIterator().accept(this)).booleanValue()
				||
				((Boolean) ifIterator.getElseIterator().accept(this)).booleanValue()
				);
	}

	@Override
	public Object visitInternIterator(InternIterator internIterator) {
		return new Boolean(this.activity.equals(internIterator.getActivity()));
	}

	@Override
	public Object visitInvokeIterator(InvokeIterator invokeIterator) {
		return new Boolean(this.activity.equals(invokeIterator.getActivity()));
	}

	@Override
	public Object visitReceiveIterator(ReceiveIterator receiveIterator) {
		return new Boolean(this.activity.equals(receiveIterator.getActivity()));
	}

	@Override
	public Object visitReplyIterator(ReplyIterator replyIterator) {
		return new Boolean(this.activity.equals(replyIterator.getActivity()));
	}

	@Override
	public Object visitSequenceIterator(SequenceIterator sequenceIterator) {
		Iterator<ActivityIterator> it = sequenceIterator.getActivities();
		while(it.hasNext()){
			if(((Boolean)it.next().accept(this)).booleanValue()){
				return new Boolean(true);
			}
		}
		return new Boolean(false);
	}

	@Override
	public Object visitMetaIterator(MetaIterator metaIterator) {
		Iterator<InternIterator> it = metaIterator.getActivities();
		while(it.hasNext()){
			if(((Boolean)it.next().accept(this)).booleanValue()){
				return new Boolean(true);
			}
		}
		return new Boolean(false);
	}

}
