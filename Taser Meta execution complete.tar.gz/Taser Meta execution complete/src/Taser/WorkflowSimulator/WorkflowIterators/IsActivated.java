package Taser.WorkflowSimulator.WorkflowIterators;

import java.util.Iterator;

public class IsActivated  implements WorkflowIteratorVisitor {
	
	public static boolean isActivated(ActivityIterator activityIterator){
		IsActivated isActivated = new IsActivated();
		return ((Boolean) activityIterator.accept(isActivated)).booleanValue();
	}
	

	@Override
	public Object visitFlowIterator(FlowIterator flowIterator) {
		Iterator<ActivityIterator> it = flowIterator.getActivities();
		while(it.hasNext()){
			if(((Boolean)it.next().accept(this)).booleanValue()){
				return new Boolean(true);
			}
		}		
		return new Boolean(false);
	}

	@Override
	public Object visitIfIterator(IfIterator ifIterator) {
		if(!(ifIterator.isThenEnabled() && ifIterator.isElseEnabled())){
			return new Boolean(true);
		}else{
			return new Boolean(false);
		}
	}

	@Override
	public Object visitInternIterator(InternIterator internIterator) {
		return new Boolean(internIterator.isHasBeenExecuted());
	}

	@Override
	public Object visitInvokeIterator(InvokeIterator invokeIterator) {
		return new Boolean(invokeIterator.isHasBeenExecuted());
	}

	@Override
	public Object visitReceiveIterator(ReceiveIterator receiveIterator) {
		return new Boolean(receiveIterator.isHasBeenExecuted());
	}

	@Override
	public Object visitReplyIterator(ReplyIterator replyIterator) {
		return new Boolean(replyIterator.isHasBeenExecuted());
	}

	@Override
	public Object visitSequenceIterator(SequenceIterator sequenceIterator) {
		if(sequenceIterator.getActivities().next() == sequenceIterator.getCurrentElement()){
			return new Boolean((Boolean) sequenceIterator.getCurrentElement().accept(this));
		}else{
			return new Boolean(true);
		}
	}

	@Override
	public Object visitMetaIterator(MetaIterator metaIterator) {
		if(metaIterator.getActivities().next() == metaIterator.getCurrentElement()){
			return new Boolean((Boolean) metaIterator.getCurrentElement().accept(this));
		}else{
			return new Boolean(true);
		}
	}

}
