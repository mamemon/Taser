package Taser.WorkflowSimulator.WorkflowIterators;

import Taser.Workflow.Activity;
import Taser.WorkflowSimulator.WorkflowSimulatorLocalController;


public class ReplyIterator extends SimpleActivityIterator {

	
	public ReplyIterator(Activity activity, WorkflowSimulatorLocalController wsc) {
		super(activity, wsc);
		this.hasBeenExecuted = false;
		this.finished = false;
	}
	
	

	@Override
	public Object accept(WorkflowIteratorVisitor wiv) {
		return wiv.visitReplyIterator(this);
	}

	

}
