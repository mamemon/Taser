package Taser.WorkflowSimulator.WorkflowIterators;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import Taser.Workflow.Activity;
import Taser.WorkflowSimulator.WorkflowSimulatorLocalController;

public class FlowIterator extends ActivityIterator {
	
	
	/** All activities iterator contained in this flow. All theses ActivityIterator are the representation
	 * of activities in the real flow
	 */
	private Collection<ActivityIterator> activities;
	

	/**
	 * Simple constructor which set activity that this is representing
	 * @param activity The activity to set.
	 */
	public FlowIterator(Activity activity, WorkflowSimulatorLocalController wsc) {
		super(activity, wsc);
		activities = new ArrayList<ActivityIterator>();		
	}
	
	/**
	 * Add a new subActivityIterator. This is used by the visitor / constructor.
	 * @param activityIterator ;)
	 */
	public void addIteratorActivity(ActivityIterator activityIterator){
		this.activities.add(activityIterator);
	}

	@Override
	public Object accept(WorkflowIteratorVisitor wiv) {
		return wiv.visitFlowIterator(this);
	}

	public Iterator<ActivityIterator> getActivities() {
		return this.activities.iterator();
	}

	public void afficheActivities(){
		System.out.println("affichage des activites du flot");
		Iterator<ActivityIterator> it = this.activities.iterator();
		while (it.hasNext()){
			ActivityIterator ai =it.next();
			System.out.println(""+ai.activity.getName());
		}
		System.out.println("fin d'affichage des activites du flot");	
	}

		
	
}
