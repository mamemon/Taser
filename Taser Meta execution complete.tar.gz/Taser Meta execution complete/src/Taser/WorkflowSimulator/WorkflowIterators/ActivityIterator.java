package Taser.WorkflowSimulator.WorkflowIterators;

import Taser.Workflow.Activity;
import Taser.WorkflowSimulator.WorkflowSimulatorLocalController;



/**
 * Abstract class of activities iterator. There are not classic iterator, they just allow to process a real simulation
 * and get all activables activities.
 * 
 */

public abstract class ActivityIterator {
	
	/** The activity which is "iterate" by the ActivityIterator */
	protected Activity activity;
	
	/** The controler in order to make some send or receive activity */
	protected WorkflowSimulatorLocalController wsc;
	
	
	 	 
	/** Visitor interface */
	public abstract Object accept(WorkflowIteratorVisitor wiv);

	
	
	/**
	 * @return the wsc
	 */
	public WorkflowSimulatorLocalController getWsc() {
		return wsc;
	}

	/**
	 * @param wsc the wsc to set
	 */
	public void setWsc(WorkflowSimulatorLocalController wsc) {
		this.wsc = wsc;
	}

	public ActivityIterator(Activity activity, WorkflowSimulatorLocalController wsc){
		this.wsc = wsc;
		this.activity = activity;
	}
	
	/**
	 * @return the activity
	 */
	public Activity getActivity() {
		return activity;
	}


	/**
	 * @param activity the activity to set
	 */
	public void setActivity(Activity activity) {
		this.activity = activity;
	}
	
	
		
	
	
		
	
	
	
	
	
	
	
	
	
	
	
	
	

	
	

	
	
	
}
