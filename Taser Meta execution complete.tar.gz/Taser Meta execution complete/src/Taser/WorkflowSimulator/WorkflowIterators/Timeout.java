package Taser.WorkflowSimulator.WorkflowIterators;

import java.util.Iterator;

import Taser.Workflow.SimpleActivity;

public class Timeout implements WorkflowIteratorVisitor {
	
	/** Activity you want to timeout */
	private SimpleActivity activity;
		
	
	
	public static void timeout(ActivityIterator activityIterator, SimpleActivity simpleActivity){
		Timeout timeout = new Timeout();
		timeout.activity = simpleActivity;
		activityIterator.accept(timeout);
	}
	
	
	@Override
	public Object visitFlowIterator(FlowIterator flowIterator) {
		Iterator<ActivityIterator> it = flowIterator.getActivities();
		while(it.hasNext()){
			ActivityIterator tmp = it.next();
			if(Contains.contains(tmp, activity)){
				tmp.accept(this);
			}
		}	
		return null;
	}

	@Override
	public Object visitIfIterator(IfIterator ifIterator) {
		if(ifIterator.isThenEnabled()){
			ifIterator.getThenIterator().accept(this);
		}
		if(ifIterator.isElseEnabled()){
			ifIterator.getElseIterator().accept(this);
		}
		
		return null;
	}

	@Override
	public Object visitInternIterator(InternIterator internIterator) {
		if(internIterator.getActivity() == this.activity){
			internIterator.setFinished(true);
		}
		return null;
	}

	@Override
	public Object visitInvokeIterator(InvokeIterator invokeIterator) {
		if(invokeIterator.getActivity() == this.activity){
			invokeIterator.setFinished(true);			
		}
		return null;
	}

	@Override
	public Object visitReceiveIterator(ReceiveIterator receiveIterator) {
		if(receiveIterator.getActivity() == this.activity){
			receiveIterator.setFinished(true);
		}
		return null;
	}

	@Override
	public Object visitReplyIterator(ReplyIterator replyIterator) {
		if(replyIterator.getActivity() == this.activity){
			replyIterator.setFinished(true);
		}
		return null;
	}

	@Override
	public Object visitSequenceIterator(SequenceIterator sequenceIterator) {
		sequenceIterator.getCurrentElement().accept(this);
		if(IsFinished.isFinished(sequenceIterator.getCurrentElement())){
			if(sequenceIterator.getActivitiesIterator().hasNext()){
				sequenceIterator.setCurrentElement(sequenceIterator.getActivitiesIterator().next());
			}else{
				sequenceIterator.setFinished(true);				
			}
		}
		return null;
	}

	@Override
	public Object visitMetaIterator(MetaIterator metaIterator) {
		metaIterator.getCurrentElement().accept(this);
		if(IsFinished.isFinished(metaIterator.getCurrentElement())){
			if(metaIterator.getActivitiesIterator().hasNext()){
				metaIterator.setCurrentElement(metaIterator.getActivitiesIterator().next());
			}else{
				metaIterator.setFinished(true);				
			}
		}
		return null;
	}



}
