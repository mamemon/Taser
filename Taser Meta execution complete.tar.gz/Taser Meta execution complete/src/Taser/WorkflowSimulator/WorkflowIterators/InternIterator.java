package Taser.WorkflowSimulator.WorkflowIterators;

import Taser.Workflow.Activity;
import Taser.WorkflowSimulator.WorkflowSimulatorLocalController;

public class InternIterator extends SimpleActivityIterator {

	

	
	public InternIterator(Activity activity, WorkflowSimulatorLocalController wsc) {
		super(activity, wsc);
	}

	

	@Override
	public Object accept(WorkflowIteratorVisitor wiv) {
		return wiv.visitInternIterator(this);
	}








	

}
