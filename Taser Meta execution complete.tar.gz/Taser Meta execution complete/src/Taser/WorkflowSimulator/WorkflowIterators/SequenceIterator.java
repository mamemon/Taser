package Taser.WorkflowSimulator.WorkflowIterators;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import Taser.Workflow.Activity;
import Taser.WorkflowSimulator.WorkflowSimulatorLocalController;

public class SequenceIterator extends ActivityIterator {
	
	/** All activities iterator contained in this sequence. All theses ActivityIterator are the representation
	 * of activities in the sequence
	 */
	private Collection<ActivityIterator> activities;
	
	/** An iterator on activities */
	private Iterator<ActivityIterator> activitiesIterator; 
	
	/** The current element of the iterator activitiesIterator */
	private ActivityIterator currentElement;
	
	/** In order to say that the sequence is ended */
	private boolean finished;
	
	
	/*
	 * Constructor
	 */
	
	/**
	 * Simple constructor which set activity that this is representing
	 * @param activity The activity to set.
	 */
	public SequenceIterator(Activity activity, WorkflowSimulatorLocalController wsc){
		super(activity, wsc);
		this.activities = new ArrayList<ActivityIterator>();
		finished = false;
	}
	
	
	/*
	 * getters and setters
	 * 
	 */
	
	public Iterator<ActivityIterator> getActivities(){
		return this.activities.iterator();
	}
	
	/**
	 * Add a new subActivityIterator. This is used by the visitor / constructor.
	 * @param activityIterator ;)
	 */
	public void addActivityIterator(ActivityIterator activityIterator){
		this.activities.add(activityIterator);
		this.activitiesIterator = this.activities.iterator();
		this.currentElement = this.activitiesIterator.next();
	}
	
	public Iterator<ActivityIterator> getActivitiesIterator(){
		return this.activitiesIterator;
	}
	
	
	public ActivityIterator getCurrentElement(){
		return this.currentElement;
	}
	
	public void setCurrentElement(ActivityIterator activityIterator){
		//System.out.println("modification de l'element courant de l'iterateur sequence "+this.activity.getName());
		//System.out.println("nouvel element courant "+activityIterator.activity.getName());
		this.currentElement = activityIterator;
	}
	

	
	public void setFinished(boolean finished){
		this.finished = true;
	}
	
	public boolean getFinished(){
		return this.finished;
	}
	

	@Override
	public Object accept(WorkflowIteratorVisitor wiv) {
		return wiv.visitSequenceIterator(this);
	}

}
