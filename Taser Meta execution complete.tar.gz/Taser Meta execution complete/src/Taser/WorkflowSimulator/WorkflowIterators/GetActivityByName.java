package Taser.WorkflowSimulator.WorkflowIterators;

import java.util.Iterator;

import Taser.Workflow.SimpleActivity;

public class GetActivityByName implements WorkflowIteratorVisitor {

	/** Searched activity's name */
	private String name;
	
	/**
	 * Looking for a simple activity in the workflow which operation's name is operationName. Return a SimpleActivity if this activity is founded
	 * , null otherwise
	 * @param activityIterator The workflow contained by an activityIterator
	 * @param operationName The searched operation
	 * @return A SimpleActivity or null
	 */
	public static SimpleActivity getActivityByName(ActivityIterator activityIterator, String operationName){
		GetActivityByName getActivityByName = new GetActivityByName();
		getActivityByName.name = operationName;
		return (SimpleActivity) activityIterator.accept(getActivityByName);
	}
	
	
	@Override
	public Object visitFlowIterator(FlowIterator flowIterator) {
		Iterator<ActivityIterator> it = flowIterator.getActivities();
		while(it.hasNext()){
			Object tmp = it.next().accept(this);
			if(tmp != null){
				return tmp;
			}
		}
		return null;
	}

	@Override
	public Object visitIfIterator(IfIterator ifIterator) {
		Object tmp = null;
		if((tmp = ifIterator.getThenIterator().accept(this))!=null){
			return tmp;
		}else{
			return ifIterator.getElseIterator().accept(this);
		}
	}

	@Override
	public Object visitInternIterator(InternIterator internIterator) {
		if(((SimpleActivity)internIterator.getActivity()).getOperation().equals(this.name)){
			return internIterator.getActivity();
		}else{		
			return null;
		}
	}

	@Override
	public Object visitInvokeIterator(InvokeIterator invokeIterator) {
		if(((SimpleActivity)invokeIterator.getActivity()).getOperation().equals(this.name)){
			return invokeIterator.getActivity();
		}else{		
			return null;
		}
	}

	@Override
	public Object visitReceiveIterator(ReceiveIterator receiveIterator) {
		if(((SimpleActivity)receiveIterator.getActivity()).getOperation().equals(this.name)){
			return receiveIterator.getActivity();
		}else{		
			return null;
		}
	}

	@Override
	public Object visitReplyIterator(ReplyIterator replyIterator) {
		if(((SimpleActivity)replyIterator.getActivity()).getOperation().equals(this.name)){
			return replyIterator.getActivity();
		}else{		
			return null;
		}
	}

	@Override
	public Object visitSequenceIterator(SequenceIterator sequenceIterator) {
		Iterator<ActivityIterator> it = sequenceIterator.getActivities();
		while(it.hasNext()){
			Object tmp = it.next().accept(this);
			if(tmp != null){
				return tmp;
			}
		}
		return null;
	}

	@Override
	public Object visitMetaIterator(MetaIterator metaIterator) {
		Iterator<InternIterator> it = metaIterator.getActivities();
		while(it.hasNext()){
			Object tmp = it.next().accept(this);
			if(tmp != null){
				return tmp;
			}
		}
		return null;
	}

}
