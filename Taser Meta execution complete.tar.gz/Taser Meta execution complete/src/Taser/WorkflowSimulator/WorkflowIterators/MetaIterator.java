package Taser.WorkflowSimulator.WorkflowIterators;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import Taser.Workflow.Activity;
import Taser.WorkflowSimulator.WorkflowSimulatorLocalController;

public class MetaIterator extends SimpleActivityIterator {
	
	/** All intern activities iterator contained in this Meta. All theses InternIterator are the representation
	 * of Intern activities in the Meta
	 */
	private Collection<InternIterator> activities;
	
	/** An iterator on Intern activities */
	private Iterator<InternIterator> activitiesIterator; 
	
	/** The current element of the iterator activitiesIterator */
	private InternIterator currentElement;
	
	/** In order to say that the meta is ended */
	//private boolean finished;
	
	
	/*
	 * Constructor
	 */
	
	/**
	 * Simple constructor which set Intern activity that this is representing
	 * @param activity The Intern activity to set.
	 */
	public MetaIterator(Activity activity, WorkflowSimulatorLocalController wsc){
		super(activity, wsc);
		this.activities = new ArrayList<InternIterator>();
		finished = false;
	}
	
	
	/*
	 * getters and setters
	 * 
	 */
	
	public Iterator<InternIterator> getActivities(){
		return this.activities.iterator();
	}
	
	/**
	 * Add a new subInternActivityIterator. This is used by the visitor / constructor.
	 * @param activityIterator ;)
	 */
	public void addActivityIterator(InternIterator activityIterator){
		this.activities.add(activityIterator);
		this.activitiesIterator = this.activities.iterator();
		this.currentElement = this.activitiesIterator.next();
	}
	
	public Iterator<InternIterator> getActivitiesIterator(){
		return this.activitiesIterator;
	}
	
	
	public InternIterator getCurrentElement(){
		return this.currentElement;
	}
	
	public void setCurrentElement(InternIterator activityIterator){
		//System.out.println("modification de l'element courant de l'iterateur sequence "+this.activity.getName());
		//System.out.println("nouvel element courant "+activityIterator.activity.getName()); // problem repalce activity with intern
		this.currentElement = activityIterator;
	}
	

		
	
/*	public boolean getFinished(){
		return this.finished;
	}*/
	

	@Override
	public Object accept(WorkflowIteratorVisitor wiv) {
		return wiv.visitMetaIterator(this);
	}

}
