package Taser.WorkflowSimulator.WorkflowIterators;

import java.util.HashMap;
import java.util.Iterator;

import Taser.Workflow.Activity;
import Taser.Workflow.ExclusiveChoice;
import Taser.Workflow.Flow;
import Taser.Workflow.Intern;
import Taser.Workflow.Invoke;
import Taser.Workflow.Receive;
import Taser.Workflow.Reply;
import Taser.Workflow.Sequence;
import Taser.Workflow.Meta;
import Taser.Workflow.Visitor;
import Taser.WorkflowSimulator.WorkflowSimulatorLocalController;

public class WorkflowIteratorConstructor implements Visitor {

	/** A controller in order to give it to Iterators */
	private WorkflowSimulatorLocalController wsc;
	
	private HashMap<ActivityIterator, Activity> activityIteratorToActivity;
	
	private HashMap<Activity, ActivityIterator> activityToActivityIterator;
	
	
	
	/**
	 * @param wsc The local controller
	 */
	public WorkflowIteratorConstructor(WorkflowSimulatorLocalController wsc) {
		super();
		this.wsc = wsc;
		this.activityIteratorToActivity = new HashMap<ActivityIterator, Activity>();
		this.activityToActivityIterator = new HashMap<Activity, ActivityIterator>();
	}





	/**
	 * @return the activityIteratorToActivity
	 */
	public HashMap<ActivityIterator, Activity> getActivityIteratorToActivity() {
		return activityIteratorToActivity;
	}





	/**
	 * @param activityIteratorToActivity the activityIteratorToActivity to set
	 */
	public void setActivityIteratorToActivity(
			HashMap<ActivityIterator, Activity> activityIteratorToActivity) {
		this.activityIteratorToActivity = activityIteratorToActivity;
	}





	/**
	 * @return the activityToActivityIterator
	 */
	public HashMap<Activity, ActivityIterator> getActivityToActivityIterator() {
		return activityToActivityIterator;
	}





	/**
	 * @param activityToActivityIterator the activityToActivityIterator to set
	 */
	public void setActivityToActivityIterator(
			HashMap<Activity, ActivityIterator> activityToActivityIterator) {
		this.activityToActivityIterator = activityToActivityIterator;
	}





	@Override
	public Object visitActivity(Activity activity) {
		return activity.accept(this);
	}



	@Override
	public Object visitExclusiveChoice(ExclusiveChoice exclusiveChoice) {
		IfIterator ifIterator = new IfIterator(exclusiveChoice, wsc);
		this.activityIteratorToActivity.put(ifIterator, exclusiveChoice);
		this.activityToActivityIterator.put(exclusiveChoice, ifIterator);
		ifIterator.setThenIterator((ActivityIterator)exclusiveChoice.getThenActivity().accept(this));
		ifIterator.setElseIterator((ActivityIterator)exclusiveChoice.getElseActivity().accept(this));
		return ifIterator;
	}

	@Override
	public Object visitFlow(Flow flow) {
		FlowIterator flowIterator = new FlowIterator(flow, wsc);
		this.activityIteratorToActivity.put(flowIterator, flow);
		this.activityToActivityIterator.put(flow, flowIterator);
		
		Iterator<Activity> it = flow.getActivities();
		//System.out.println("CONSTRUCTION DU FLOW ITERATOR");
		
		while(it.hasNext()){
			
			Activity a = it.next();
			//System.out.println("ajout d'un �l�ment "+a.getName());
			flowIterator.addIteratorActivity((ActivityIterator)a.accept(this));
		}
		return flowIterator;
	}

	@Override
	public Object visitIntern(Intern intern) {
		InternIterator internIterator = new InternIterator(intern, wsc);
		this.activityIteratorToActivity.put(internIterator, intern);
		this.activityToActivityIterator.put(intern, internIterator);
		return internIterator;
	}

	@Override
	public Object visitInvoke(Invoke invoke) {
		InvokeIterator invokeIterator = new InvokeIterator(invoke, wsc);
		this.activityIteratorToActivity.put(invokeIterator, invoke);
		this.activityToActivityIterator.put(invoke, invokeIterator);
		return invokeIterator;
	}

	@Override
	public Object visitReceive(Receive receive) {
		ReceiveIterator receiveIterator = new ReceiveIterator(receive, wsc);
		this.activityIteratorToActivity.put(receiveIterator, receive);
		this.activityToActivityIterator.put(receive, receiveIterator);		
		return receiveIterator;
	}

	@Override
	public Object visitReply(Reply reply) {
		ReplyIterator replyIterator = new ReplyIterator(reply, wsc);
		this.activityIteratorToActivity.put(replyIterator, reply);
		this.activityToActivityIterator.put(reply, replyIterator);
		return replyIterator;
	}

	@Override
	public Object visitSequence(Sequence sequence) {
		//System.out.println("WorkflowIteratorConstructor : visite de la sequence "+ sequence.getName());
		SequenceIterator sequenceIterator = new SequenceIterator(sequence, wsc);
		this.activityIteratorToActivity.put(sequenceIterator, sequence);
		this.activityToActivityIterator.put(sequence, sequenceIterator);		
		Iterator<Activity> it = sequence.getActivities();
		
		while(it.hasNext()){
			//System.out.println("WorkflowIteratorConstructor : ajout d'un element a " + sequence.getName());
			sequenceIterator.addActivityIterator((ActivityIterator) it.next().accept(this));
		}
			
		return sequenceIterator;
	}

	@Override
	public Object visitMeta(Meta meta) {
		//System.out.println("WorkflowIteratorConstructor : visite Meta "+ meta.getName());
		MetaIterator metaIterator = new MetaIterator(meta, wsc);
		this.activityIteratorToActivity.put(metaIterator, meta);
		this.activityToActivityIterator.put(meta, metaIterator);		
		Iterator<Intern> it = meta.getActivities();
		
		while(it.hasNext()){
			//System.out.println("WorkflowIteratorConstructor : ajout d'un element a " + meta.getName());
			metaIterator.addActivityIterator((InternIterator) it.next().accept(this));
		}
			
		return metaIterator;
	}
}
