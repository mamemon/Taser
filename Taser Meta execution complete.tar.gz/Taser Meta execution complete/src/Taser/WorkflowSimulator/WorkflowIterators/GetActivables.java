package Taser.WorkflowSimulator.WorkflowIterators;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import Taser.Workflow.SimpleActivity;
import Taser.Workflow.Intern;
import Taser.Workflow.Activity;
public class GetActivables implements WorkflowIteratorVisitor {

//private Collection<Activity> activables = new ArrayList<Activity>();

	
	@SuppressWarnings("unchecked")
	public static Collection<SimpleActivity> getActivables(ActivityIterator activityIterator){
		//System.out.println("I am in get activates");		
		GetActivables getActivables = new GetActivables();
		if(activityIterator != null){
			return (Collection<SimpleActivity>) activityIterator.accept(getActivables);
		}else{
			return new ArrayList<SimpleActivity>();
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public Object visitFlowIterator(FlowIterator flowIterator) {
		//System.out.println("GetActivable pour flow "+flowIterator.activity.getName());
		Collection<SimpleActivity> activables = new ArrayList<SimpleActivity>();
		Iterator<ActivityIterator> it = flowIterator.getActivities();
		while(it.hasNext()){
			activables.addAll((Collection<SimpleActivity>) it.next().accept(this));
		}
		//System.out.println(activables);
		return activables;
	}
	
	

	@SuppressWarnings("unchecked")
	@Override
	public Object visitIfIterator(IfIterator ifIterator) {
		Collection<SimpleActivity> activables = new ArrayList<SimpleActivity>();
		if(ifIterator.isThenEnabled()){
			activables.addAll(((Collection<SimpleActivity>)ifIterator.getThenIterator().accept(this)));
		}
		if(ifIterator.isElseEnabled()){
			activables.addAll(((Collection<SimpleActivity>)ifIterator.getElseIterator().accept(this)));
		}
		return activables;
	}

	

	@Override
	public Object visitInvokeIterator(InvokeIterator invokeIterator) {
		Collection<SimpleActivity> activables = new ArrayList<SimpleActivity>();	
		if(!invokeIterator.isHasBeenExecuted()){
			activables.add((SimpleActivity) invokeIterator.getActivity());
		}		
		return activables;
	}

	@Override
	public Object visitReceiveIterator(ReceiveIterator receiveIterator) {
		//System.out.println("GetActivable pour receive "+receiveIterator.activity.getName());
		Collection<SimpleActivity> activables = new ArrayList<SimpleActivity>();	
		if(!receiveIterator.isHasBeenExecuted()){
			activables.add((SimpleActivity) receiveIterator.getActivity());
		}		
		//System.out.println(activables);
		return activables;
	}

	@Override
	public Object visitReplyIterator(ReplyIterator replyIterator) {
		Collection<SimpleActivity> activables = new ArrayList<SimpleActivity>();	
		if(!replyIterator.isHasBeenExecuted()){
			activables.add((SimpleActivity) replyIterator.getActivity());
		}		
		return activables;
	}

	@Override
	public Object visitInternIterator(InternIterator internIterator) {
		//System.out.println("GetActivable pour intern "+internIterator.activity.getName());
		Collection<SimpleActivity> activables = new ArrayList<SimpleActivity>();	
		if(!internIterator.isHasBeenExecuted()){
			activables.add((SimpleActivity) internIterator.getActivity());
		}	
		//System.out.println(activables);
		return activables;
	}

	@Override
	public Object visitSequenceIterator(SequenceIterator sequenceIterator) {
		//System.out.println("GetActivable pour sequence "+sequenceIterator.activity.getName());
		if(!sequenceIterator.getFinished()){
			return sequenceIterator.getCurrentElement().accept(this);
		}else{
			return new ArrayList<SimpleActivity>();			
		}
	}

	@Override
	public Object visitMetaIterator(MetaIterator metaIterator) {
		//System.out.println("GetActivable pour Meta "+metaIterator.activity.getName());
		//if(metaIterator.hasNext()){System.out.println("yes hasNxt");}
			
		/*if(!MetaIterator.isHasBeenExecuted()){
			activables.add((SimpleActivity) internIterator.getActivity());
		}*/	

		/*if(!metaIterator.getFinished()){
	
		activables.add(metaIterator.getCurrentElement().getActivity());
		System.out.println("SIZE OF  META "+activables.size());

		}*/

		Collection<SimpleActivity> activables = new ArrayList<SimpleActivity>();
		Iterator<InternIterator> it = metaIterator.getActivities();
		while(it.hasNext()){
			activables.addAll((Collection<SimpleActivity>) it.next().accept(this));
		}
		//System.out.println("SIZE OF  META "+activables.size());
		return activables;

		/*if(!metaIterator.getFinished()){
			
			return metaIterator.getCurrentElement().accept(this);
		}else{
			return new ArrayList<SimpleActivity>();			
		}*/
	}

}
