package Taser.WorkflowSimulator.WorkflowIterators;

import Taser.Workflow.Activity;
import Taser.WorkflowSimulator.WorkflowSimulatorLocalController;

public class IfIterator extends ActivityIterator {

	private boolean thenEnabled;
	
	private boolean elseEnabled;
	
	private ActivityIterator thenIterator;
	
	private ActivityIterator elseIterator;
	

	
	
	/**
	 * @return the thenIterator
	 */
	public ActivityIterator getThenIterator() {
		return thenIterator;
	}

	/**
	 * @param thenIterator the thenIterator to set
	 */
	public void setThenIterator(ActivityIterator thenIterator) {
		this.thenIterator = thenIterator;
	}

	/**
	 * @return the elseIterator
	 */
	public ActivityIterator getElseIterator() {
		return elseIterator;
	}

	/**
	 * @param elseIterator the elseIterator to set
	 */
	public void setElseIterator(ActivityIterator elseIterator) {
		this.elseIterator = elseIterator;
	}

		
	public IfIterator(Activity activity, WorkflowSimulatorLocalController wsc) {
		super(activity, wsc);
		this.thenEnabled = true;
		this.elseEnabled = true;
	}

	

	
	
	

	
	/**
	 * @return the thenEnabled
	 */
	public boolean isThenEnabled() {
		return thenEnabled;
	}

	/**
	 * @param thenEnabled the thenEnabled to set
	 */
	public void setThenEnabled(boolean thenEnabled) {
		this.thenEnabled = thenEnabled;
	}

	/**
	 * @return the elseEnabled
	 */
	public boolean isElseEnabled() {
		return elseEnabled;
	}

	/**
	 * @param elseEnabled the elseEnabled to set
	 */
	public void setElseEnabled(boolean elseEnabled) {
		this.elseEnabled = elseEnabled;
	}

	@Override
	public Object accept(WorkflowIteratorVisitor wiv) {
		return wiv.visitIfIterator(this);
	}

	
	
	
	

}
