package Taser.WorkflowSimulator.WorkflowIterators;

import java.util.Iterator;

public class IsFinished implements WorkflowIteratorVisitor {
	
	public static boolean isFinished(ActivityIterator activityIterator){
		IsFinished isFinished = new IsFinished();
		return ((Boolean) activityIterator.accept(isFinished)).booleanValue();
	}
	

	@Override
	public Object visitFlowIterator(FlowIterator flowIterator) {
		System.out.print("iterateur Isfinished pour flow"+ flowIterator.activity.getName());
		Iterator<ActivityIterator> it = flowIterator.getActivities();
		while(it.hasNext()){
			if(!((Boolean)it.next().accept(this)).booleanValue()){
				System.out.println(" EstTermin� ; false");
				return new Boolean(false);
			}
		}
		System.out.println(" EstTermin� ; true");
		return new Boolean(true);
	}

	@Override
	public Object visitIfIterator(IfIterator ifIterator) {
		boolean result = true;
		if(ifIterator.isThenEnabled()){
			result = ((Boolean) ifIterator.getThenIterator().accept(this)).booleanValue();
		}
		if(ifIterator.isElseEnabled()){
			result = result && ((Boolean) ifIterator.getElseIterator().accept(this)).booleanValue();
		}
		return new Boolean(result);
	}

	@Override
	public Object visitInternIterator(InternIterator internIterator) {
		//System.out.println("iterateur Isfinished pour interne"+ internIterator.activity.getName()+" estTermin� "+internIterator.isFinished());
		return new Boolean(internIterator.isFinished());
	}

	@Override
	public Object visitInvokeIterator(InvokeIterator invokeIterator) {
		//System.out.println("iterateur Isfinished pour invoke"+ invokeIterator.activity.getName());
		return new Boolean(invokeIterator.isFinished());
	}

	@Override
	public Object visitReceiveIterator(ReceiveIterator receiveIterator) {
		//System.out.println("iterateur Isfinished pour receuve"+ receiveIterator.activity.getName()+" est Termin� "+receiveIterator.isFinished());
		return new Boolean(receiveIterator.isFinished());
	}

	@Override
	public Object visitReplyIterator(ReplyIterator replyIterator) {
		return new Boolean(replyIterator.isFinished());
	}

	@Override
	public Object visitSequenceIterator(SequenceIterator sequenceIterator) {
		//System.out.println("iterateur Isfinished pour sequence"+ sequenceIterator.activity.getName()+ " estTermin�e : "+sequenceIterator.getFinished());
		return new Boolean(sequenceIterator.getFinished());
	}

	@Override
	public Object visitMetaIterator(MetaIterator metaIterator) {
		//System.out.println("iterateur Isfinished pour sequence"+ sequenceIterator.activity.getName()+ " estTermin�e : "+sequenceIterator.getFinished());
		return new Boolean(metaIterator.isFinished());
	}

}
