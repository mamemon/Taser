package Taser.WorkflowSimulator.WorkflowIterators;

import Taser.Workflow.Activity;
import Taser.WorkflowSimulator.WorkflowSimulatorLocalController;

public abstract class SimpleActivityIterator extends ActivityIterator {

	/** In order to say if the activity is finished */
	protected boolean finished;	

	/** In order to know if this activity has been executed */
	protected boolean hasBeenExecuted;
	
	
	/**
	 * Simple constructor
	 * @param activity The activity which this is representing
	 * @param wsc The local controller
	 */
	public SimpleActivityIterator(Activity activity, WorkflowSimulatorLocalController wsc) {
		super(activity, wsc);
		this.finished = false;
		this.hasBeenExecuted = false;
	}

	/**
	 * @return the finished
	 */
	public boolean isFinished() {
		return finished;
	}

	/**
	 * @param finished the finished to set
	 */
	public void setFinished(boolean finished) {
		this.finished = finished;
	}

	/**
	 * @return the hasBeenExecuted
	 */
	public boolean isHasBeenExecuted() {
		return hasBeenExecuted;
	}

	/**
	 * @param hasBeenExecuted the hasBeenExecuted to set
	 */
	public void setHasBeenExecuted(boolean hasBeenExecuted) {
		this.hasBeenExecuted = hasBeenExecuted;
	}

	

}
