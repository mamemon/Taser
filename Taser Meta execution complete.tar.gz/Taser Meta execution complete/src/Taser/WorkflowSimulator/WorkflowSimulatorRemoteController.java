package Taser.WorkflowSimulator;

import java.rmi.Remote;
import java.rmi.RemoteException;

	/**
	 * This interface provides all remote methods of the Workflow controller. It allows to call those methods with RMI. * 
	 */
	
	public interface WorkflowSimulatorRemoteController extends Remote {
	
	
	/**
	 * Restart the workflow simulation from the begining. It end the current activity simulation, go back to the first
	 * activity and restore workflow's initial state . All datas, transactions, are deleted...
	 * @throws RemoteException
	 */
	public void restart() throws RemoteException;
	
	
	
	
	
	

	
	/**
	 * Starts a new request demanded by a remote simulator. The remote simulator is blocked until it receives an answer or until it gets a time out. 
	 * The local simulator executes the request only if its current activity is a BPEL's Receive activity, otherwise the request is stored until it 
	 * will be processable.
	 * @param request the request
	 * @throws RemoteException
	 */
	public void request(Request request) throws RemoteException;
	
	
	/**
	 * This is an answer to a request. After that a remote simulator requested an operation,  the local simulator send its response and continue its 
	 * activities. 
	 * @param Response the response
	 * @throws RemoteException
	 */
	public void response(Response response) throws RemoteException;
	
	
	
	
}
