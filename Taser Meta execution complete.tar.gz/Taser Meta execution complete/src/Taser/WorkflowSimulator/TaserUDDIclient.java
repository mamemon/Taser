package Taser.WorkflowSimulator;

import java.rmi.AccessException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

import Taser.TaserException;
import TaserUDDI.TaserUDDIserver;

public class TaserUDDIclient {

	private String taserUDDIserverIP;
	
	private static final int TASER_UDDI_PORT = 1099;
	private static final int TASER_SIMULATOR_PORT = 1100;
	
	
	public TaserUDDIclient(){
		this.taserUDDIserverIP = new String("127.0.0.1");
	}


	/**
	 * @return the taserUDDIserverIP
	 */
	public String getTaserUDDIserverIP() {
		return taserUDDIserverIP;
	}


	/**
	 * @param taserUDDIserverIP the taserUDDIserverIP to set
	 * @throws TaserException 
	 */
	public void setTaserUDDIserverIP(String taserUDDIserverIP) throws TaserException {
		if(taserUDDIserverIP.matches("^\\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\b$")){
			this.taserUDDIserverIP = taserUDDIserverIP;
		}else{
			TaserException e = new TaserException();
			e.setMessage(taserUDDIserverIP + " ip given to set the TaserUDDIserver's ip doesn't have an IPV4 form. Please check that you entered the right ip! ");			
			throw e;
		}
		
		
	}
	
	
	
	
	public void registerService(String serviceName, WorkflowSimulatorRemoteController wsrc) throws TaserException{
		Registry reg = null;
		try {
			reg = LocateRegistry.getRegistry(this.taserUDDIserverIP, TASER_UDDI_PORT);
		} catch (RemoteException e) {
			TaserException.throwTaserException("Error while getting the UDDIserver registry : " + e.getMessage());
		}
		TaserUDDIserver taserUDDIserver = null;
		try {
			taserUDDIserver = (TaserUDDIserver)reg.lookup("TaserUDDIserver");
		} catch (AccessException e) {
			TaserException.throwTaserException("Error while getting the UDDIserver, don't have the permission : " + e.getMessage());
		} catch (RemoteException e) {
			TaserException.throwTaserException("Error while getting the UDDIserver : " + e.getMessage());
		} catch (NotBoundException e) {
			TaserException.throwTaserException("Error while getting the UDDIserver, server doesn't exists on this registry : " + e.getMessage());
		}
		
		try {
			taserUDDIserver.registerService(serviceName);
		} catch (RemoteException e) {
			TaserException.throwTaserException("Error while removing the requested service : " + e.getMessage());
		}
	
	}
	
	
	public void removeService(String serviceName) throws TaserException{
		
			Registry reg = null;
			try {
				reg = LocateRegistry.getRegistry(this.taserUDDIserverIP, TASER_UDDI_PORT);
			} catch (RemoteException e) {
				TaserException.throwTaserException("Error while getting the UDDIserver registry : " + e.getMessage());
			}
			TaserUDDIserver taserUDDIserver = null;
			try {
				taserUDDIserver = (TaserUDDIserver)reg.lookup("TaserUDDIserver");
			} catch (AccessException e) {
				TaserException.throwTaserException("Error while getting the UDDIserver, don't have the permission : " + e.getMessage());
			} catch (RemoteException e) {
				TaserException.throwTaserException("Error while getting the UDDIserver : " + e.getMessage());
			} catch (NotBoundException e) {
				TaserException.throwTaserException("Error while getting the UDDIserver, server doesn't exists on this registry : " + e.getMessage());
			}
			
			try {
				taserUDDIserver.removeService(serviceName);
			} catch (RemoteException e) {
				TaserException.throwTaserException("Error while removing the requested service : " + e.getMessage());
			}
			
			
			
			
	}
	
	
	public WorkflowSimulatorRemoteController getService(String serviceName) throws TaserException{		
		
			Registry reg = null;
			try {
				reg = LocateRegistry.getRegistry(this.taserUDDIserverIP, TASER_UDDI_PORT);
			} catch (RemoteException e) {
				TaserException.throwTaserException("Error while getting the UDDIserver registry : " + e.getMessage());				
			}
			TaserUDDIserver taserUDDIserver = null;
			try {
				taserUDDIserver = (TaserUDDIserver) reg.lookup("TaserUDDIserver");
			} catch (AccessException e) {
				TaserException.throwTaserException("Error while getting the UDDIserver, don't have the permission : " + e.getMessage());
			} catch (RemoteException e) {
				TaserException.throwTaserException("Error while getting the UDDIserver : " + e.getMessage());
			} catch (NotBoundException e) {
				TaserException.throwTaserException("Error while getting the UDDIserver, server doesn't exists on this registry : " + e.getMessage());
			}
			
			String ip = null;
			try {
				ip = taserUDDIserver.getServiceIp(serviceName);
			} catch (RemoteException e) {
				TaserException.throwTaserException("Error while getting the requested service's IP : " + e.getMessage());
			}
			
			try {
				reg = LocateRegistry.getRegistry(ip, TASER_SIMULATOR_PORT);
			} catch (RemoteException e) {
				TaserException.throwTaserException("Error while getting the requested service's registry : " + e.getMessage());
			}
			
			WorkflowSimulatorRemoteController wsrc = null;
			try {
				wsrc =  (WorkflowSimulatorRemoteController) reg.lookup(serviceName);
			} catch (AccessException e) {
				TaserException.throwTaserException("Error while getting the requested service's remote controller don't have the permission : " + e.getMessage());
			} catch (RemoteException e) {
				TaserException.throwTaserException("Error while getting the requested service's remote controller : " + e.getMessage());
			} catch (NotBoundException e) {
				TaserException.throwTaserException("Error while getting the resquested service's remote controller, does'nt exists on this registry : " + e.getMessage());
			}
			return wsrc;
		
	}
	
	
	
	
	
	
}
