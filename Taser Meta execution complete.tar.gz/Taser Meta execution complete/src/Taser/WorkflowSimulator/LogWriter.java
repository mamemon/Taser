package Taser.WorkflowSimulator;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import Taser.TaserException;

public class LogWriter {

	
	/** The file name */
	private String fileName;
	
	/** The file */
	private BufferedWriter file;
	
	public LogWriter() throws TaserException{
		this.fileName = new String("log");
		try {
			this.file = new BufferedWriter(new FileWriter(this.fileName));
		} catch (IOException e) {
			TaserException.throwTaserException("Error during the creation of the log file : " + e.getMessage());
		}
		
	}


	/**
	 * @return the fileName
	 */
	public String getFileName() {
		return fileName;
	}


	/**
	 * @param fileName the fileName to set
	 * @throws TaserException
	 */
	public void setFileName(String fileName) throws TaserException {
		try {
			file.close();
		} catch (IOException e) {
			TaserException.throwTaserException("Error during closing the logfile \""+this.fileName+"\" : " + e.getMessage());	
		}
		this.fileName = fileName;
		try {
			file = new BufferedWriter(new FileWriter(this.fileName));
		} catch (IOException e) {
			TaserException.throwTaserException("Error during the creation of the log file : " + e.getMessage());
		}		
	}
	
	
	
	public void write(String toWrite) throws TaserException{
		try{
			this.file.write(System.currentTimeMillis()+" "+toWrite);
			this.file.newLine();
			this.file.flush();
		}catch(IOException e){
			TaserException.throwTaserException("Error during writing into the log file : " + e.getMessage());
		}
		
	}
	
	
	
	
	
	
	
}
