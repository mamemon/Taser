package Taser.WorkflowSimulator;

/**
 * This is a Tripleclass which contain three objects of differents types. 
 * @param <T> Type of the triple's first element 
 * @param <S> Type of the triple's second element
 * @param <K> Type of the triple's third element
 */


public class Triple<T, S, K> {

	/** Triple's first element*/
	private T first;
	
	/** Triple's second element*/
	private S second;
	
	
	private K third;
	
	/*
	 * Constructors 
	 */
	/**
	 * Default constructor, it sets fields to null.
	 */
	public Triple(){
		super();
		first = null;
		second = null;
		third = null;
	}
	
	/**
	 * Constructors settings fields with the given objects
	 * @param first The triple's first element to set
	 * @param second The triple's second element to set
	 * @param third The triple's third element to set
	 */
	public Triple(T first,S second, K third){
		super();
		this.first = first;
		this.second = second;
		this.third = third;
	}

	/**
	 * @return the triple's first element
	 */
	public T getFirst() {
		return first;
	}

	/**
	 * @param first the triple's first element to set
	 */
	public void setFirst(T first) {
		this.first = first;
	}

	/**
	 * @return the triple's second element
	 */
	public S getSecond() {
		return second;
	}

	/**
	 * @param second the triple's second element to set
	 */
	public void setSecond(S second) {
		this.second = second;
	}

	/**
	 * @return the third the triple's third element
	 */
	public K getThird() {
		return third;
	}

	/**
	 * @param third the triple's third element to set
	 */
	public void setThird(K third) {
		this.third = third;
	}
	
	
	
	
}
