package Taser.Workflow;






/**
 * Classe abstraite représentant une activitée de workflow. 
 */

public abstract class Activity implements Visitable{
	
	/** Le nom de l'activitée */
	private String name;
	

	
	/**
	 * Constructeur par défaut, initialise simplement les champs
	 */
	public Activity(){
		this.name = new String();
	}
	
	
	/**
	 * Surcharge de constructeur qui remplis le nom de l'activitée
	 * @param name Nom de l'activitée.
	 */
	public Activity(String name) {
		this.name = name;
	}





	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * @return The whole workflow written in BPEL
	 */
	public java.lang.String toString(){
		return WorkflowToXml.workflowToXml(this);
	}


	

	
	
}
