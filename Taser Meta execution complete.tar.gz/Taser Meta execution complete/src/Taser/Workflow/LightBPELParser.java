package Taser.Workflow;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;

import Taser.TaserException;


/**
 * Parses a BPEL XML file and construct an intern representation of this file. This parser dont use the complete DTD of BPEL language but a simplified 
 * version.
 *
 */


public class LightBPELParser {
	
	/**
	 * Parse a BPEL XML file and construct an intern representation of this file. 
	 * @param fileName The complete file name which has to be parsed
	 * @return The activity corresponding to the BPEL XML file
	 * @throws TaserException 
	 */
	public static Workflow parseLightBPELFile(String fileName) throws  TaserException{
		LightBPELParser parser = new LightBPELParser(fileName);
		return parser.workflow;
	}
	
	
	
	
	
	
	/*
	 * Attributes
	 */
	
	

	


	/** The workflow name*/
	private Workflow workflow;
	
	
	/*
	 * Constructor
	 */
	
	/** This constructors load an XML file and build an intern XML structure of this file.
	 * @param fileName The complete file name which has to be parsed	 * 
	 * @throws TaserException 
	 */
	public LightBPELParser(String fileName) throws TaserException{
		
		this.workflow = new Workflow();		
		
		SAXBuilder sxb = new SAXBuilder();

		org.jdom.Document document = null;
		try {
			document = sxb.build(new File(fileName));
		} catch (JDOMException e) {
			TaserException taserException = new TaserException();
			taserException.setMessage("Error during parsing the XML file \""+fileName+"\"\n Message : " + e.getMessage());
			throw taserException;				
		} catch (IOException e) {
			TaserException taserException = new TaserException();
			taserException.setMessage("Error during opening and reading the XML file \""+fileName+"\"\n Message : " + e.getMessage());
			throw taserException;	
		}
		Element root = document.getRootElement();
		this.parseProcess(root);
			

		
	}
	/*
	 * Internal methods which are parsing the XML intern representation of the workflow
	 * 
	 */
	
	
	/**
	 * @return the workflow
	 */
	public Workflow getWorkflow() {
		return workflow;
	}


	/**
	 * Parse a generic XML intern representation of an activity
	 * @param currentElement The xml element to parse
	 * @return The activity corresponding to currentElement
	 */
	private Activity parseActivity(Element currentElement){
		Activity activity = null;
		if(currentElement.getName().equals("sequence")){
			activity = this.parseSequence(currentElement);
		}
		if(currentElement.getName().equals("flow")){
			activity = this.parseFlow(currentElement);
		}
		if(currentElement.getName().equals("if")){
			activity = this.parseExclusiveChoice(currentElement);
		}
		if(currentElement.getName().equals("intern")){
			activity = this.parseIntern(currentElement);
		}
		if(currentElement.getName().equals("invoke")){
			activity = this.parseInvoke(currentElement);
		}
		if(currentElement.getName().equals("receive")){
			activity = this.parseReceive(currentElement);
		}
		if(currentElement.getName().equals("reply")){
			activity = this.parseReply(currentElement);
		}	
		
		// Meta Activity Starts
		if(currentElement.getName().equals("meta")){ 
			activity = this.parseMeta(currentElement);
		//System.out.println(currentElement.getName());
		}	
		// Meta Activity Ends 
		
		return activity;
	}
	
	
	@SuppressWarnings("unchecked")
	private void parseProcess(Element currentElement){
		
		this.workflow.setName(currentElement.getAttributeValue("name"));
		
		Iterator<Element> it = currentElement.getChildren().iterator();
		while(it.hasNext()){
			Element itElement = it.next();
			if(itElement.getName().equals("variables")){
				Iterator<Variable> variables = this.parseVariablesDeclaration(itElement);
				while(variables.hasNext()){
					this.workflow.addVariable(variables.next());
				}
			}else{
				this.workflow.setActivity(this.parseActivity(itElement));
			}
			
		}
	}
	
	
	
	
	

	/**
	 * Parse an XML intern representation of a sequence
	 * @param currentElement The xml element to parse
	 * @return The sequence corresponding to currentElement
	 */
	@SuppressWarnings("unchecked")
	private Sequence parseSequence(Element currentElement){		
		Sequence sequence = new Sequence();		
		sequence.setName(currentElement.getAttributeValue("name"));
		
		Iterator<Element> it = (currentElement.getChildren()).iterator();
		
		while(it.hasNext()){
			sequence.addActivity(this.parseActivity(it.next()));
		}
		
		return sequence;
	}

	/**
	 * Parse an XML intern representation of an Meta
	 * @param currentElement The xml element to parse
	 * @return The Intern corresponding to currentElement
	 */
	@SuppressWarnings("unchecked")
	private Meta parseMeta(Element currentElement){
		Meta meta = new Meta();		
		meta.setName(currentElement.getAttributeValue("name"));
		//System.out.println(currentElement.getAttributeValue("name")); // extra added for print
		
		Iterator<Element> it = (currentElement.getChildren()).iterator();
		
		while(it.hasNext()){
			meta.addActivity(this.parseActivity(it.next()));
		}
		
		return meta;

	}

	
	/**
	 * Parse an XML intern representation of a Flow
	 * @param currentElement The xml element to parse
	 * @return The Flow corresponding to currentElement
	 */
	@SuppressWarnings("unchecked")
	private Flow parseFlow(Element currentElement){
		//System.out.println("debut de creatin d'un flot");
		Flow flow = new Flow();
		flow.setName(currentElement.getAttributeValue("name"));
		Iterator<Element> it = currentElement.getChildren().iterator();
		//System.out.println("it "+it);
		while(it.hasNext()){
			//System.out.println("ajout d'un element au flot");
			flow.addActivity(this.parseActivity(it.next()));
		}
		//System.out.println("fin de construciton du flot"+flow);
		return flow;
	}
	
	

	
	/**
	 * Parse an XML intern representation of an ExclusiveChoice
	 * @param currentElement The xml element to parse
	 * @return The ExclusiveChoice corresponding to currentElement
	 */
	@SuppressWarnings("unchecked")
	private ExclusiveChoice parseExclusiveChoice(Element currentElement){
		ExclusiveChoice exclusiveChoice = new ExclusiveChoice();
		exclusiveChoice.setName(currentElement.getAttributeValue("name"));
		
		ArrayList<Element> elseIfElements= new ArrayList<Element>();
		Activity elseActivity = null ;
		
		Iterator<Element> it = currentElement.getChildren().iterator();
		while(it.hasNext()){
			Element currentChildElement = it.next();
			
			if(currentChildElement.getName().equals("else")){
				elseActivity = this.parseActivity((Element)currentChildElement.getChildren().get(0));
			}else if(currentChildElement.getName().equals("elseif")){
				elseIfElements.add(currentChildElement);
			}else if(currentChildElement.getName().equals("condition")){
				exclusiveChoice.setCondition(currentChildElement.getText());
			}else{
				exclusiveChoice.setThenActivity(this.parseActivity((Element)currentChildElement));
			}			
		}
		this.buildElseIf(exclusiveChoice, elseIfElements, elseActivity);
		return exclusiveChoice;
	}
	
	
	/**
	 * Parse an XML intern representation of an Intern
	 * @param currentElement The xml element to parse
	 * @return The Intern corresponding to currentElement
	 */
	@SuppressWarnings("unchecked")
	private Intern parseIntern(Element currentElement){
		Intern intern = new Intern();		
		intern.setName(currentElement.getAttributeValue("name"));
		
		//Parsing dependencies
		Iterator<Element> it = currentElement.getChildren().iterator();
		while(it.hasNext()){
			intern.addDependancy(this.parseDependencies(it.next()));
		}
		
		
		return intern;
	}
	
	private Dependency parseDependencies(Element currentElement){
		Dependency dependency = new Dependency();		
		dependency.setIn(this.workflow.getVariable(currentElement.getAttributeValue("in")));
		dependency.setOut(this.workflow.getVariable(currentElement.getAttributeValue("out")));		
		return dependency;
	}
	
	
	
	
	/**
	 * Parse an XML intern representation of an Invoke
	 * @param currentElement The xml element to parse
	 * @return The Invoke corresponding to currentElement
	 */
	@SuppressWarnings("unchecked")
	private Invoke parseInvoke(Element currentElement){
		Invoke invoke = new Invoke();		
		invoke.setName(currentElement.getAttributeValue("name"));
		invoke.setPartnerLink(currentElement.getAttributeValue("partnerLink"));
		invoke.setOperation(currentElement.getAttributeValue("operation"));
		if(currentElement.getAttributeValue("synchronous") != null){
			if(currentElement.getAttributeValue("synchronous").equals("true")){
				invoke.setSync(true);				
			}else{
				invoke.setSync(false);
			}
		}

		
		//Adding variables
		Iterator<Element> it = currentElement.getChildren().iterator();
		while(it.hasNext()){
			Element itElement = it.next();
			if(itElement.getName().equals("inputVariables")){
				Iterator<Variable> inputVariablesIterator = this.parseVariables(itElement);
				while(inputVariablesIterator.hasNext()){
					invoke.addInputVariable(inputVariablesIterator.next());
				}
					
			}else if(itElement.getName().equals("outputVariable")){
				Iterator<Variable> outputVariableIterator = this.parseVariables(itElement);
				if(outputVariableIterator.hasNext()){
					invoke.setOutputVariable(outputVariableIterator.next());
				}
			}
		}
		
		return invoke;
	}
	
	
	/**
	 * Parse an XML intern representation of a Receive
	 * @param currentElement The xml element to parse
	 * @return The Receive corresponding to currentElement
	 */
	@SuppressWarnings("unchecked")
	private Receive parseReceive(Element currentElement){
		Receive receive = new Receive();
		receive.setName(currentElement.getAttributeValue("name"));
		receive.setPartnerLink(currentElement.getAttributeValue("partnerLink"));
		receive.setOperation(currentElement.getAttributeValue("operation"));

		
		//Adding variables
		Iterator<Element> it = currentElement.getChildren().iterator();
		while(it.hasNext()){
			Element itElement = it.next();
			if(itElement.getName().equals("inputVariables")){
				Iterator<Variable> inputVariablesIterator = this.parseVariables(itElement);
				while(inputVariablesIterator.hasNext()){
					receive.addInputVariable(inputVariablesIterator.next());
				}
					
			}
		}
		
		
		
		return receive;
	}
	
	/**
	 * Parse an XML intern representation of a Reply
	 * @param currentElement The xml element to parse
	 * @return The Reply corresponding to currentElement
	 */
	@SuppressWarnings("unchecked")
	private Reply parseReply(Element currentElement){
		Reply reply = new Reply();
		reply.setName(currentElement.getAttributeValue("name"));
		reply.setPartnerLink(currentElement.getAttributeValue("partnerLink"));
		reply.setOperation(currentElement.getAttributeValue("operation"));
		
		//Adding variables
		Iterator<Element> it = currentElement.getChildren().iterator();
		while(it.hasNext()){
			Element itElement = it.next();
			if(itElement.getName().equals("outputVariable")){
				Iterator<Variable> outputVariableIterator = this.parseVariables(itElement);
				if(outputVariableIterator.hasNext()){
					reply.setOutputVariable(outputVariableIterator.next());
				}
			}
		}
		
		
		return reply;
	}
	
	/**
	 * Parse variables tag contain directly by the same father and return an Iterator on their internal representation
	 * @param currentElement The father containing all variables tags
	 * @return An iterator on their internal representation
	 */
	@SuppressWarnings("unchecked")
	private Iterator<Variable> parseVariables(Element currentElement){
		ArrayList<Variable> variables = new ArrayList<Variable>();
	
		Iterator<Element> it = currentElement.getChildren().iterator();
		while(it.hasNext()){
			variables.add(this.parseVariable(it.next()));
		}
		
		
		return variables.iterator();
	}
	
	@SuppressWarnings({ "unchecked" })
	private Iterator<Variable> parseVariablesDeclaration(Element currentElement){
		ArrayList<Variable> variables = new ArrayList<Variable>();
	
		Iterator<Element> it = currentElement.getChildren().iterator();
		while(it.hasNext()){
			variables.add(this.parseVariableDeclaration(it.next()));
		}
		
		
		return variables.iterator();
	}
	
	
	
	
	/**
	 * Parse a <variable name = " name "\> tag
	 * @param currentElement dom element
	 * @return a variable corresponding to the XML tag
	 */
	private Variable parseVariable(Element currentElement){
		return this.workflow.getVariable(currentElement.getAttributeValue("name"));
	}
	
	
	private Variable parseVariableDeclaration(Element currentElement){
	 	return new Variable(currentElement.getAttributeValue("name"));
	}
	

	
	
	
	@SuppressWarnings("unchecked")
	private void buildElseIf(ExclusiveChoice exclusiveChoice, Collection<Element> elseIfElements, Activity elseActivity){
		if(elseIfElements.isEmpty()){
			exclusiveChoice.setElseActivity(elseActivity);
		}else{
		
			//Creating a sub if
			ExclusiveChoice ec = new ExclusiveChoice();
			exclusiveChoice.setElseActivity(ec);
			
			//getting first elseif element from condition
			Iterator<Element> it = elseIfElements.iterator();
			Element tmp = it.next();
			it.remove();
			
			//Getting condition and then activity from XML
			it = tmp.getChildren().iterator();
			while(it.hasNext()){
				Element currentChildElement = it.next();
				if(currentChildElement.getName().equals("condition")){
					ec.setCondition(currentChildElement.getText());
				}else{
					ec.setThenActivity(parseActivity(currentChildElement));
				}	
			}
			
			// Recursive call
			buildElseIf(ec, elseIfElements, elseActivity);			
		}
	}
	
	
	
	
}
