package Taser.Workflow;

import java.util.Iterator;

public class WorkflowToXml implements Visitor {

	public static String workflowToXml(Activity activity){
		WorkflowToXml work = new WorkflowToXml();
		String result = "<?xml version=\"1.0\"?>\n";
		result += activity.accept(work);
		return result;
	}
	
	
	@Override
	public Object visitActivity(Activity activity) {		
		return activity.accept(this);
	}

	

	@Override
	public Object visitExclusiveChoice(ExclusiveChoice exclusiveChoice) {
		String xml = new String();
		xml += "<if name = \""+exclusiveChoice.getName()+"\">\n";
		xml += "<condition>\n";
		xml += exclusiveChoice.getCondition()+"\n";
		xml += "</condition>\n";
		xml += exclusiveChoice.getThenActivity().accept(this);
		xml += "<else>\n";
		xml += exclusiveChoice.getElseActivity().accept(this);
		xml += "</else>\n";
		xml += "</if>\n";		
		return xml;
	}

	@Override
	public Object visitFlow(Flow flow) {
		String xml = new String();
		xml += "<flow name = \"" + flow.getName() + "\">\n";
		Iterator<Activity> it = flow.getActivities();
		while(it.hasNext()){
			xml += it.next().accept(this);
		}
		xml += "</flow>\n";		
		return xml;
	}

	@Override
	public Object visitIntern(Intern intern) {
		String xml = new String();
		
		xml += "<intern ";
		xml += "name = \""+intern.getName()+"\"";
		xml += " />\n";
		
		return xml;
	}

	@Override
	public Object visitInvoke(Invoke invoke) {
		String xml = new String();
		
		xml += "<invoke";
		xml += " name = \""+invoke.getName()+"\"";
		xml += " partnerLink = \""+invoke.getPartnerLink() + "\"";
		xml += " operation = \""+invoke.getOperation() + "\"";
		xml += " />\n";
		
		
		//Variables
		xml += "<inputVariables>\n";
		xml += this.translateVariables(invoke.getInputVariables());
		xml += "</inputVariables>\n";
		
		xml += "<outputVariable>\n";
		xml += this.translateVariable(invoke.getOutputVariable());
		xml += "</outputVariable>\n";
		
		
		
		return xml;
		
	}

	@Override
	public Object visitReceive(Receive receive) {
		String xml = new String();
		
		xml += "<receive";
		xml += " name = \""+receive.getName()+"\"";
		xml += " partnerLink = \""+receive.getPartnerLink() + "\"";
		xml += " operation = \""+receive.getOperation() + "\"";
		//Variables
		xml += "<inputVariables>\n";
		xml += this.translateVariables(receive.getInputVariables());
		xml += "</inputVariables>\n";
		
		
		xml += " />\n";
		
		return xml;
	}

	@Override
	public Object visitReply(Reply reply) {
		String xml = new String();
		
		xml += "<reply";
		xml += " name = \""+reply.getName()+"\"";
		xml += " partnerLink = \""+reply.getPartnerLink() + "\"";
		xml += " operation = \""+reply.getOperation() + "\"";
		//Variables
		xml += "<outputVariable>\n";
		xml += this.translateVariable(reply.getOutputVariable());
		xml += "</outputVariable>\n";
		
		xml += " />\n";
		
		return xml;
	}

	@Override
	public Object visitSequence(Sequence sequence) {
		String xml = new String();
		
		xml += "<sequence";
		xml += " name = \"" + sequence.getName() + "\"";
		xml += ">\n";
		Iterator<Activity> it = sequence.getActivities();
		while(it.hasNext()){
			xml += it.next().accept(this);
		}
		xml += "</sequence>";	
		
		return xml;
	}
	
	@Override
	public Object visitMeta(Meta meta) {
		String xml = new String();
		
		xml += "<meta";
		xml += " name = \"" + meta.getName() + "\"";
		xml += ">\n";
		Iterator<Intern> it = meta.getActivities();
		while(it.hasNext()){
			xml += it.next().accept(this);
		}
		xml += "</meta>";	
		
		return xml;
	}
	
	private String translateVariables(Iterator<Variable> variables){
		
		String xml = new String();
		while(variables.hasNext()){
			xml += (this.translateVariable(variables.next()) + "\n");
		}
		return xml;		
	}
	
	private String translateVariable(Variable variable){
		if(variable != null){
			return new String("<variable name =\" " +variable.getName() + "\" />");
		}else{
			return new String("<variable name =\"unknown\" />");
		}
	}
	

	
	
	
	
	
	
	
	
	
	
	

}
