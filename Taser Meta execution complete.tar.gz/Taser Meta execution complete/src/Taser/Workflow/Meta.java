package Taser.Workflow;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;


/**
 * Activitée Meta de BPEL
 *
 */
public class Meta extends SimpleActivity {

	/** Les activitées à executer en séquences */
	private Collection<Intern> activities;
	
	/*
	 *  Constructeur
	 */
	
	public Meta(){
		super();
		activities = new ArrayList<Intern>();
	}
	
	
	/*
	 * Getters and Setters
	 */
	
	/**
	 * Ajoute une activitée à executer en séquence
	 * @param activity Activitée à rajouter
	 */
	public void addActivity(Activity activity){
		this.activities.add((Intern)activity);
	}
	
	/**
	 * Retourne les activitées à executer en séquence
	 * @return Itérateur sur les activitées
	 */
	public Iterator<Intern> getActivities(){
		return this.activities.iterator();
	}
	
	
	
	
	/*
	 * (non-Javadoc)
	 * @see Workflow.Visitable#accept(Workflow.Visitor)
	 */
	
	
	@Override
	public Object accept(Visitor visitor) {
		return visitor.visitMeta(this);

	}


}
