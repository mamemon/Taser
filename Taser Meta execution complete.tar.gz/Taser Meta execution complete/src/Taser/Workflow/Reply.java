package Taser.Workflow;


/**
 * Activitée Reply de BPEL
 *
 */
public class Reply extends SimpleActivity {

	
	/** Lien du client recevant les données */
	private String partnerLink;
	
	/** Nom de l'opération du Reply */
	private String operation;
	
	/** Nom de la variable de sortie */
	private Variable outputVariable;
	
	
	/*
	 * Constructeurs
	 * 
	 */
	



	
	
	public Reply(){
		super();
		this.partnerLink = new String();
		this.operation = new String();
		this.outputVariable = new Variable(new String());
	}
	
	
	
	
	
	
	/*
	 * Getters and Setters
	 */
	
	 
	 
	/**
	 * @return The partner link
	 */
	public String getPartnerLink() {
		return partnerLink;
	}


	/**
	 * @param partnerLink le partnerLink à modifier
	 */
	public void setPartnerLink(String partnerLink) {
		this.partnerLink = partnerLink;
	}


	/**
	 * @return L'operation
	 */
	public String getOperation() {
		return operation;
	}


	/**
	 * @param operation L'operation à modifier
	 */
	public void setOperation(String operation) {
		this.operation = operation;
	}


	/**
	 * @return L'outputVariable
	 */
	public Variable getOutputVariable() {
		return outputVariable;
	}


	/**
	 * @param outputVariable L'outputVariable à modifier
	 */
	public void setOutputVariable(Variable outputVariable) {
		this.outputVariable = outputVariable;
	}

	
	
	
	
	
	
	
	/*
	 * (non-Javadoc)
	 * @see Workflow.Visitable#accept(Workflow.Visitor)
	 */


	@Override
	public Object accept(Visitor visitor) {
		return visitor.visitReply(this);
	}


}
