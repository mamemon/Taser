package Taser.Workflow;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;



public class Invoke extends SimpleActivity{

	/** partner's name on which the operation is called*/
	private String partnerLink;
	
	/** Invoked operation */
	private String operation;
	
	/** Input variables */
	private Collection<Variable> inputVariables;
	
	/** Nom de la variable de sortie */
	private Variable outputVariable;
	
	/** Sync is true if this invoke is synchronous and false if this is asynchronous. A synchronous invoke is an invoke 
	 * which is waiting for a response when it is executed.
	 */
	
	private boolean sync;

		
	
	/*
	 * Constructeurs
	 * 
	 */
	
	
	
	public Invoke(){
		super();
		this.partnerLink = new String();
		this.operation = new String();
		this.inputVariables = new ArrayList<Variable>();
		this.sync = true;

	}
	
	
	/*
	 * Getters et Setters
	 */
	
	 
	 
	/**
	 * @return Le partnerLink
	 */
	public String getPartnerLink() {
		return partnerLink;
	}


	/**
	 * @param partnerLink le partnerLink à modifier
	 */
	public void setPartnerLink(String partnerLink) {
		this.partnerLink = partnerLink;
	}


	/**
	 * @return L'operation
	 */
	public String getOperation() {
		return operation;
	}


	/**
	 * @param operation L'operation à modifier
	 */
	public void setOperation(String operation) {
		this.operation = operation;
	}


	/**
	 * @return L'outputVariable
	 */
	public Variable getOutputVariable() {
		return outputVariable;
	}


	/**
	 * @param outputVariable L'outputVariable à modifier
	 */
	public void setOutputVariable(Variable outputVariable) {
		this.outputVariable = outputVariable;
	}
	
	/**
	 * @return L'inputVariable
	 */
	public Iterator<Variable> getInputVariables() {
		return this.inputVariables.iterator();
	}


	/**
	 * @param inputVariable L'inputVariable à modifier
	 */
	public void addInputVariable(Variable inputVariable) {
		this.inputVariables.add(inputVariable);
	}

	/*
	 * (non-Javadoc)
	 * @see Workflow.Visitable#accept(Workflow.Visitor)
	 */
	
	/**
	 * Set the value of the synchronous status of this invoke. Sync is true if this invoke is synchronous and false if this is asynchronous. A synchronous invoke is an invoke 
	 * which is waiting for a response when it is executed.
	 * @param sync the sync to set
	 */
	public void setSync(boolean sync) {
		this.sync = sync;
	}


	/**
	 * @return the sync. Sync is true if this invoke is synchronous and false if this is asynchronous. A synchronous invoke is an invoke 
	 * which is waiting for a response when it is executed.
	 */
	public boolean isSync() {
		return sync;
	}


	@Override
	public Object accept(Visitor visitor) {
		return visitor.visitInvoke(this);
		
	}
	
	
	
	
	
	
}
