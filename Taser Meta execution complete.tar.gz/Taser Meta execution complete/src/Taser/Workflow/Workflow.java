package Taser.Workflow;

import java.util.HashMap;
import java.util.Iterator;

/**
 * Class which represent a BPEL workflow, with a name, variables declarations, activites, etc... 
 *
 */

public class Workflow {

	/** The workflow's name */
	private String name;

	/** The workflow root activity */
	private Activity activity;
	
	/** Variables */
	private HashMap<String, Variable> variables;
	
	
	public Workflow(){
		this.variables = new HashMap<String, Variable>();
	}
	

	/**
	 * Add new variable into the workflow
	 * @param variable The new variable to add
	 */
	public void addVariable(Variable variable){
		this.variables.put(variable.getName(), variable);
	}
	
	/**
	 * Return an iterator on all workflow's variables
	 * @return an iterator on all workflow's variables
	 */
	public Iterator<Variable> getVariables(){
		return this.variables.values().iterator();
	}
	
	/**
	 * Return the variable corresponding to the name if it exists, null otherwise
	 * @param name The name of the requested variable
	 * @return The variable corresponding to the given name if this variable exists, null otherwise
	 */
	public Variable getVariable(String name){
		return this.variables.get(name);
	}
	
	
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the activity
	 */
	public Activity getActivity() {
		return activity;
	}

	/**
	 * @param activity the activity to set
	 */
	public void setActivity(Activity activity) {
		this.activity = activity;
	}

}
