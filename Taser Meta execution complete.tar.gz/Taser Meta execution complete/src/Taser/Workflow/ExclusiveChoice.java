package Taser.Workflow;








/**
 * Choix exclusif BPEL
 *
 */
public class ExclusiveChoice extends ComposedActivity {
	

	
	/** Condition du choix exlusif exprimée en XPath*/
	private String condition;
	
	/** Activitée executée si la condition est rendu vraie */
	private Activity thenActivity;

	/** Activitée executée si la condition est rendu vraie */
	private Intern thenIntern;

	/** Activitée executée si la condition est rendu fausse */
	private Intern elseIntern;
	
	/** Activitée executée si la condition est rendu fausse */
	private Activity elseActivity;
	
	/*
	 * Constructeur
	 */
	
	/**
	 * @param condition
	 * @param thenActivity
	 * @param elseActivity
	 */
	public ExclusiveChoice(String condition, Activity thenActivity,
			Activity elseActivity) {
		super();
		this.condition = condition;
		this.thenActivity = thenActivity;
		this.elseActivity = elseActivity;
	
	}
	
	
		public ExclusiveChoice(String condition, Intern thenIntern,
			Intern elseIntern) {
		super();
		this.condition = condition;
		this.thenIntern = thenIntern;
		this.elseIntern = elseIntern;
	
	}
	public ExclusiveChoice(){
		super();
		condition = new String();
		thenActivity = null;
		elseActivity = null;
		thenIntern = null;
		elseIntern = null;

	}
	
	
	
	/*
	 * Getters et Setters
	 */
	
	

	
	
	/**
	 * @return La condition
	 */
	public String getCondition() {
		return condition;
	}

	/**
	 * @param condition La condition à modifier
	 */
	public void setCondition(String condition) {
		this.condition = condition;
	}

	/**
	 * @return La thenActivity
	 */
	public Activity getThenActivity() {
		if (elseIntern !=null)
		return thenIntern;
		else	
		return thenActivity;		
		
	}

	/**
	 * @return La thenActivity
	 */
	
	/*public Intern getThenActivity() {
		return thenIntern;
	}*/

	/**
	 * @param thenActivity la thenActivity à modifier
	 */
	public void setThenActivity(Activity thenActivity) {
		this.thenActivity = thenActivity;
	}

	/**
	 * @param thenActivity la thenActivity à modifier
	 */
	
	public void setThenActivity(Intern thenIntern) {
		this.thenIntern = thenIntern;
	}

	/**
	 * @return La elseActivity
	 */
	public Activity getElseActivity() {
		if (elseIntern !=null)
		return elseIntern;
		else	
		return elseActivity;
	}

	/**
	 * @return La elseActivity
	 */
	
	/*public Intern getElseActivity() {
		return elseIntern;
	}*/
	/**
	 * @param elseActivity La elseActivity à modifier
	 */
	public void setElseActivity(Activity elseActivity) {
		this.elseActivity = elseActivity;
	}

	/**
	 * @param elseActivity La elseActivity à modifier
	 */
	
	public void setElseActivity(Intern elseIntern) {
		this.elseIntern = elseIntern;
	}
	
	/*
	 * (non-Javadoc)
	 * @see Workflow.Visitable#accept(Workflow.Visitor)
	 */

	@Override
	public Object accept(Visitor visitor) {
		return visitor.visitExclusiveChoice(this);		
	}

	

	
	
	
	
	
}
