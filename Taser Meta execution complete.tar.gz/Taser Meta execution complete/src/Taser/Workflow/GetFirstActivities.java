package Taser.Workflow;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public class GetFirstActivities implements Visitor {

	/**
	 * Return the first activities reachable from the given activity
	 * @param activity An activity
	 * @return the first activities reachable from the given activity
	 */
	@SuppressWarnings("unchecked")
	public static Iterator<SimpleActivity> getFirstActivities(Activity activity){
		GetFirstActivities gfa = new GetFirstActivities();
		ArrayList<SimpleActivity> al = (ArrayList<SimpleActivity>) activity.accept(gfa);
		return al.iterator();
	}
	
	
	@Override
	public Object visitActivity(Activity activity) {
		return activity.accept(this);
	}

	@SuppressWarnings("unchecked")
	@Override
	public Object visitExclusiveChoice(ExclusiveChoice exclusiveChoice) {
		ArrayList<SimpleActivity> al = new ArrayList<SimpleActivity>();
		al.addAll((ArrayList<SimpleActivity>) exclusiveChoice.getThenActivity().accept(this));
		al.addAll((ArrayList<SimpleActivity>) exclusiveChoice.getElseActivity().accept(this));
		return al;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Object visitFlow(Flow flow) {
		ArrayList<SimpleActivity> al = new ArrayList<SimpleActivity>();
		Iterator<Activity> it = flow.getActivities();
		while(it.hasNext()){
			al.addAll((Collection<? extends SimpleActivity>) it.next().accept(this));
		}		
		return al;
	}

	@Override
	public Object visitIntern(Intern intern) {
		ArrayList<SimpleActivity> al = new ArrayList<SimpleActivity>();
		al.add(intern);
		return al;
	}

	@Override
	public Object visitInvoke(Invoke invoke) {
		ArrayList<SimpleActivity> al = new ArrayList<SimpleActivity>();
		al.add(invoke);
		return al;
	}

	@Override
	public Object visitReceive(Receive receive) {
		ArrayList<SimpleActivity> al = new ArrayList<SimpleActivity>();
		al.add(receive);
		return al;
	}

	@Override
	public Object visitReply(Reply reply) {
		ArrayList<SimpleActivity> al = new ArrayList<SimpleActivity>();
		al.add(reply);
		return al;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Object visitSequence(Sequence sequence) {
		ArrayList<SimpleActivity> al = new ArrayList<SimpleActivity>();
		Iterator<Activity> it = sequence.getActivities();
		if(it.hasNext()){
			al.addAll((Collection<		SimpleActivity>) it.next().accept(this));
		}		
		return al;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public Object visitMeta(Meta meta) {
		ArrayList<Intern> al = new ArrayList<Intern>();
		Iterator<Intern> it = meta.getActivities();
		if(it.hasNext()){
			al.addAll((Collection<Intern>) it.next().accept(this));
		}		
		return al;
	}

}
