package Taser.Workflow;

/**
 * Interface Visitor permettant de naviguer à travers le workflow. Voir design pattern Visitor
 */

public interface Visitor {
	
	/**
	 * Visite une activitée
	 * @param activity Activitée a visister
	 */
	public Object visitActivity(Activity activity);
	
	
	
	/**
	 * Visite un ExclusiveChoice
	 * @param exclusiveChoice exclusiveChoice à visiter
	 */
	public Object visitExclusiveChoice(ExclusiveChoice exclusiveChoice);
	
	/**
	 * Visite un Flow
	 * @param flow flow à visiter
	 */
	public Object visitFlow(Flow flow);
	
	/**
	 * Visite une sequence
	 * @param sequence sequence à visiter
	 */
	public Object visitSequence(Sequence sequence);
	
	
	
	/**
	 * Visite un Intern
	 * @param intern intern à visiter
	 */
	public Object visitIntern(Intern intern);

	/**
	 * Visite un Meta
	 * @param intern Meta à visiter
	 */
	public Object visitMeta(Meta meta);
	
	/**
	 * Visite un Receive
	 * @param receive receive à visiter
	 */
	public Object visitReceive(Receive receive);
	
	
	/**
	 * Visite un Reply
	 * @param reply reply  à visiter
	 */
	public Object visitReply(Reply reply);
	
	
	/**
	 * Visite un invoke
	 * @param invoke invoke  à visiter
	 */
	public Object visitInvoke(Invoke invoke);
	

	
}
