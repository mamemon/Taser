package Taser.Workflow;

import java.util.Iterator;



public class WorkflowDepth implements Visitor {
	
	
	public static int workflowDepth(Activity activity){
		WorkflowDepth wd = new WorkflowDepth();
		return ((Integer)activity.accept(wd)).intValue();
	}
	
	@Override
	public Object visitActivity(Activity activity){
		return activity.accept(this);
	}
	
	@Override
	public Object visitExclusiveChoice(ExclusiveChoice exclusiveChoice) {
		int thenDepth = ((Integer)exclusiveChoice.getThenActivity().accept(this)).intValue();
		int elseDepth = ((Integer)exclusiveChoice.getElseActivity().accept(this)).intValue();
		int max = Math.max(thenDepth, elseDepth)+2;
		return new Integer(max);
		
	}

	@Override
	public Object visitFlow(Flow flow) {
		int max = 0;
		Iterator<Activity> it = flow.getActivities();
		while(it.hasNext()){
			int current = ((Integer) it.next().accept(this)).intValue();
			if(current > max){
				max = current;
			}
		}
		return new Integer(max+2);
	}

	@Override
	public Object visitIntern(Intern intern) {
		return new Integer(1);
	}

	@Override
	public Object visitInvoke(Invoke invoke) {
		return new Integer(1);
	}

	@Override
	public Object visitReceive(Receive receive) {
		return new Integer(1);
	}

	@Override
	public Object visitReply(Reply reply) {
		return new Integer(1);
	}

	@Override
	public Object visitSequence(Sequence sequence) {
		int sum = 0;
		Iterator<Activity> it = sequence.getActivities();
		while(it.hasNext()){
			sum += ((Integer)it.next().accept(this)).intValue();
		}
		return new Integer(sum);		
	}

	@Override
	public Object visitMeta(Meta meta) {
		int sum = 0;
		Iterator<Intern> it = meta.getActivities();
		while(it.hasNext()){
			sum += ((Integer)it.next().accept(this)).intValue();
		}
		return new Integer(sum);		
	}

	
}
