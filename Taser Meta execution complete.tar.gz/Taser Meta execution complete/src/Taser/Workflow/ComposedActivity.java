package Taser.Workflow;

/**
 * 
 * Classe abstraite représentant les activitées composées  d'activity basiques
 *
 */

public abstract class ComposedActivity extends Activity {
	/**
	 * Constructeur par défaut faisant appel au constructeur de la classe mère
	 */
	ComposedActivity(){
		super();
	}
}
