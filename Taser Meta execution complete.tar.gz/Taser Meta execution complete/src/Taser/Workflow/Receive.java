package Taser.Workflow;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

/**
 * Activitée Receive de BPEL
 * @author rquintin
 *
 */
public class Receive extends SimpleActivity {

	
	/** Lien du client envoyant les données */
	private String partnerLink;
	
	/** Nom de l'opération du receive */
	private String operation;
	
	/** Nom de la variable d'entrée */
	private Collection<Variable> inputVariables;
	
	
	/*
	 * Constructeurs
	 * 
	 */
	



	
	public Receive(){
		super();
		this.partnerLink = new String();
		this.operation = new String();
		this.inputVariables = new ArrayList<Variable>();
	}
	
	
	
	
	
	
	/*
	 * Getters et Setters
	 */
	
	 
	 
	/**
	 * @return Le partnerLink
	 */
	public String getPartnerLink() {
		return partnerLink;
	}


	/**
	 * @param partnerLink le partnerLink à modifier
	 */
	public void setPartnerLink(String partnerLink) {
		this.partnerLink = partnerLink;
	}


	/**
	 * @return L'operation
	 */
	public String getOperation() {
		return operation;
	}


	/**
	 * @param operation L'operation à modifier
	 */
	public void setOperation(String operation) {
		this.operation = operation;
	}


	/**
	 * @return An iterator on the receive's input variables
	 */
	public Iterator<Variable> getInputVariables() {
		return inputVariables.iterator();
	}


	/**
	 * Add a variable at the receive's input
	 * @param inputVariable The variable to add at the input
	 */
	public void addInputVariable(Variable inputVariable) {
		this.inputVariables.add(inputVariable);
	}


	
	
	
	
	/*
	 * (non-Javadoc)
	 * @see Workflow.Visitable#accept(Workflow.Visitor)
	 */


	@Override
	public Object accept(Visitor visitor) {
		return visitor.visitReceive(this);
	}


}
