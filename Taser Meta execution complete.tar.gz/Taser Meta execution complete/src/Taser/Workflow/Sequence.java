package Taser.Workflow;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;


/**
 * Activitée Sequence de BPEL
 * @author rquintin
 *
 */
public class Sequence extends ComposedActivity {
	
	/** Les activitées à executer en séquences */
	private Collection<Activity> activities;
	
	/*
	 *  Constructeur
	 */
	
	public Sequence(){
		super();
		activities = new ArrayList<Activity>();
	}
	
	
	/*
	 * Getters et Setters
	 */
	
	/**
	 * Ajoute une activitée à executer en séquence
	 * @param activity Activitée à rajouter
	 */
	public void addActivity(Activity activity){
		this.activities.add(activity);
	}
	
	/**
	 * Retourne les activitées à executer en séquence
	 * @return Itérateur sur les activitées
	 */
	public Iterator<Activity> getActivities(){
		return this.activities.iterator();
	}
	
	
	
	
	/*
	 * (non-Javadoc)
	 * @see Workflow.Visitable#accept(Workflow.Visitor)
	 */
	
	
	@Override
	public Object accept(Visitor visitor) {
		return visitor.visitSequence(this);

	}

}
