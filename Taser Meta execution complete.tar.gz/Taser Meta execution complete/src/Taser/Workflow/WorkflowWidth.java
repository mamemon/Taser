package Taser.Workflow;

import java.util.Iterator;

public class WorkflowWidth implements Visitor {
	
	public static int workflowWidth(Activity activity){
		WorkflowWidth ww = new WorkflowWidth();
		return ((Integer)activity.accept(ww)).intValue();
	}
	
	@Override
	public Object visitActivity(Activity activity) {
		return activity.accept(this);
	}

	@Override
	public Object visitExclusiveChoice(ExclusiveChoice exclusiveChoice) {
		int thenWidth = ((Integer) exclusiveChoice.getThenActivity().accept(this)).intValue();
		int elseWidth = ((Integer) exclusiveChoice.getElseActivity().accept(this)).intValue();
		int sum = thenWidth + elseWidth + 1;
		return new Integer(sum);
	}

	@Override
	public Object visitFlow(Flow flow) {
		int sum = 0;
		Iterator<Activity> it = flow.getActivities();
		while(it.hasNext()){
			sum += ((Integer)it.next().accept(this)).intValue();
		}
		
		return new Integer(sum);
	}

	@Override
	public Object visitIntern(Intern intern) {
		return new Integer(1);
	}

	@Override
	public Object visitInvoke(Invoke invoke) {
		return new Integer(1);
	}

	@Override
	public Object visitReceive(Receive receive) {
		return new Integer(1);
	}

	@Override
	public Object visitReply(Reply reply) {
		return new Integer(1);
	}

	@Override
	public Object visitSequence(Sequence sequence) {
		int max = 0;
		Iterator<Activity> it = sequence.getActivities();
		while(it.hasNext()){
			int tmp = ((Integer) it.next().accept(this)).intValue();
			if(tmp > max){
				max = tmp;
			}
		}
		return new Integer(max);
	}

	@Override
	public Object visitMeta(Meta meta) {
		int max = 0;
		Iterator<Intern> it = meta.getActivities();
		while(it.hasNext()){
			int tmp = ((Integer) it.next().accept(this)).intValue();
			if(tmp > max){
				max = tmp;
			}
		}
		return new Integer(max);
	}


}
