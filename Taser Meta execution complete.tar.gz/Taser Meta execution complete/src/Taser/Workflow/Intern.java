package Taser.Workflow;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;


/**
 * BPEL intern activity representation. It's a SimpleActivity but it also makes dependancies between variables when the intern is processed
 */

public class Intern extends SimpleActivity {

	
	/** All dependencies which are made between variables when the intern is processed */
	private Collection<Dependency> dependencies;
	
	
	/*
	 * Constructeur 
	 */
	
	public Intern(){
		super();
		this.dependencies = new ArrayList<Dependency>();
		
	}

	
	
	/**
	 * Add a new dependency to the intern
	 * @param dependancy
	 */
	public void addDependancy(Dependency dependancy){
		this.dependencies.add(dependancy);
	}
	
	/**
	 * Return an iterator on all dependencies which are made between variables when the intern is processed
	 * @return an iterator on all dependencies which are made between variables when the intern is processed
	 */
	public Iterator<Dependency> getDependencies(){
		return this.dependencies.iterator();
	}
	
	
	
	/*
	 * (non-Javadoc)
	 * @see Workflow.Visitable#accept(Workflow.Visitor)
	 */
	@Override
	public Object accept(Visitor visitor) {
		return visitor.visitIntern(this);
	}

}
