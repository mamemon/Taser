package Taser.Workflow;

/**
 * Interface d'objets visitables. Voir design pattern Visitor
 * 
 *
 */
public interface Visitable {
	/**
	 * Demande à l'objet d'accepter et d'executer un visitor sur lui même. Voir design pattern Visitor
	 * @param visitor Visitor à accepter sur this
	 */
	public Object accept(Visitor visitor);
}
