package Taser.Workflow;

/**
 * 
 * Abstract class which defines basic operations on Simple activities i.e on activites which doesn't contains activities.
 *
 */
public abstract class SimpleActivity extends Activity {

	
	/** Activity's operation name */
	protected String operation;
	
	
	/**
	 * Default constructor which call the super class constructor
	 */
	public SimpleActivity(){
		super();
		this.operation = new String();
	}
	
	/**
	 * Return simple activity operation's name
	 * @return simple activity operation's name
	 */
	public String getOperation(){
		return this.operation;
	}
	
	/**
	 * Set the operation's name
	 * @param operation
	 */
	public void setOperation(String operation){
		System.out.println("association d'une operation a une activite simple ; " + operation);
		this.operation = operation;
	}


	
	
	

}
