package Taser.Workflow;

/**
 * This class symbolize the dependency between two variables in an activity. This mean that the variable "in" is used 
 * to calculate the variable out.
 *
 */


public class Dependency {

		/** The variable used to calculate the variable "out" */
		private Variable in;
		
		/** The variable which depend to variable "in" */
		private Variable out;

		/**
		 * @return The variable used to calculate the variable "out"
		 */
		public Variable getIn() {
			return in;
		}

		/**
		 * @param in The variable used to calculate the variable "out"
		 */
		public void setIn(Variable in) {
			this.in = in;
		}

		/**
		 * @return The variable which depend to variable "in"
		 */
		public Variable getOut() {
			return out;
		}

		/**
		 * @param out The variable which depend to variable "in"
		 */
		public void setOut(Variable out) {
			this.out = out;
		}
		
		
		/**
		 * Give the same status as in to out
		 */
		public void transferStatus(){
			out.setCorrupted(in.isCorrupted());
		}
		
		
	
}
