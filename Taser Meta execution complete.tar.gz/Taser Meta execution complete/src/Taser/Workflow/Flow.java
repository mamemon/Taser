package Taser.Workflow;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;


/**
 * Activitée Flow de BPEL
 */

public class Flow extends ComposedActivity {

	/** Les activitées du flow à executer en parallèle */
	private Collection<Activity> activities;
	
	
	/*
	 * Constructeurs
	 */

	public Flow(){
		super();
		//System.out.println("cretion d'une activite flow");
		activities = new ArrayList<Activity>();
	}
	
	/*
	 * Getters et Setters
	 * 
	 */
	
	
	/**
	 * Renvoie un iterateur sur les activitées du flow
	 * @return iterator sur les activitées activities
	 */
	public Iterator<Activity> getActivities(){
		return activities.iterator();
	}
	
	/**
	 * Ajoute une activitée au Flow
	 * @param activity activitée à rajouter
	 */
	public void addActivity(Activity activity){
		//System.out.println("ajout d'une activite");
		this.activities.add(activity);
	}
	
	
	/*
	 * (non-Javadoc)
	 * @see Workflow.Visitable#accept(Workflow.Visitor)
	 */
	
	@Override
	public Object accept(Visitor visitor) {
		return visitor.visitFlow(this);
	}

}
