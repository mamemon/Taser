package Taser;

/**
 * Exception in order to simplified exception treatment in the controller
 */

public class TaserException extends Exception {

	/**
	 * Automatically genereted by eclipse
	 */
	private static final long serialVersionUID = -4883374421199425501L;
	
	/** Exception message */
	private String message;


	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}


	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}
	
	/**
	 * Throw a new TaserException with the given message
	 * @param message The message to throw
	 * @throws TaserException
	 */
	public static void throwTaserException(String message) throws TaserException{
		TaserException e = new TaserException();
		e.setMessage(message);
		throw e;
	}
	
	
	
	
}
