package TaserUDDI;

import java.rmi.Remote;
import java.rmi.RemoteException;



/**
 * Provide an interface for taserUDDI. 
 * @author rquintin
 *
 */
public interface TaserUDDIserver extends Remote {

	
	public void registerService(String serviceName) throws RemoteException;
	
	public void removeService(String serviceName) throws RemoteException;
	
	public String getServiceIp(String serviceName) throws RemoteException;
	
}
